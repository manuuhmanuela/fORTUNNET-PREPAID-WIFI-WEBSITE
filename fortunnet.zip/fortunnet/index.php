<?php
session_start();
require_once __DIR__ . '/config/db.php';

// Fetch live data
$packages = $pdo->query("SELECT p.*, c.name AS cat FROM packages p
    JOIN categories c ON c.id = p.category_id
    WHERE p.status='active' ORDER BY p.price ASC LIMIT 6")->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY id LIMIT 8")->fetchAll();

$totalUsers    = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalSubs     = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status='paid'")->fetchColumn();
$totalHotspots = $pdo->query("SELECT COUNT(*) FROM hotspots")->fetchColumn();

// Handle contact form
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    if ($name && $email && $message) {
        $stmt = $pdo->prepare("INSERT INTO contact_messages (name,email,subject,message) VALUES (?,?,?,?)");
        $stmt->execute([$name, $email, $subject, $message]);
        $msg = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Thank you, <strong>".htmlspecialchars($name)."</strong>! Your message was received.</div>";
    } else {
        $msg = "<div class='alert alert-danger'><i class='fas fa-exclamation-circle'></i> Please fill in all required fields.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FortunNet | Prepaid WiFi in Kenya</title>
<meta name="description" content="Fast, reliable and affordable prepaid WiFi. Choose your package, pay via M-Pesa, and get online instantly.">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
  :root{ --brand:#6610f2; --brand-2:#0d6efd; --dark:#0f172a; }
  html{ scroll-behavior:smooth; scroll-padding-top:80px; }
  body{ font-family:'Plus Jakarta Sans',sans-serif; background:#f6f7fb; color:#1e293b; }

  /* NAVBAR */
  .navbar{ background:rgba(15,23,42,.97); backdrop-filter:blur(10px); }
  .navbar-brand{ font-weight:800; color:#fff!important; }
  .navbar-brand i{ color:#a78bfa; }
  .navbar .nav-link{ color:#cbd5e1!important; font-weight:500; }
  .navbar .nav-link:hover, .navbar .nav-link.active{ color:#fff!important; }

  .btn-brand{ background:linear-gradient(90deg,var(--brand),var(--brand-2)); color:#fff; border:none; font-weight:600; transition:.3s; }
  .btn-brand:hover{ color:#fff; transform:translateY(-2px); box-shadow:0 10px 20px rgba(102,16,242,.35); }
  .btn-outline-brand{ border:2px solid var(--brand); color:var(--brand); font-weight:600; }
  .btn-outline-brand:hover{ background:var(--brand); color:#fff; }

  /* Admin button — circular icon style */
  .btn-admin{
    width:42px; height:42px; border-radius:50%;
    display:inline-flex; align-items:center; justify-content:center;
    padding:0; border:2px solid #fbbf24; color:#fbbf24; background:transparent;
    transition:.25s;
  }
  .btn-admin:hover{
    background:#fbbf24; color:#0f172a;
    box-shadow:0 6px 18px rgba(251,191,36,.45);
    transform:translateY(-2px);
  }

  /* HERO */
  .hero{ background:radial-gradient(circle at top right,#3b0764,#0f172a 60%); color:#fff; padding:120px 0 100px; position:relative; overflow:hidden; }
  .hero::before{ content:''; position:absolute; width:500px;height:500px; background:radial-gradient(circle,rgba(102,16,242,.4),transparent 70%); top:-100px;right:-100px; border-radius:50%; }
  .hero::after{ content:''; position:absolute; width:400px;height:400px; background:radial-gradient(circle,rgba(13,110,253,.35),transparent 70%); bottom:-150px;left:-100px; border-radius:50%; }
  .hero h1{ font-size:clamp(2rem,5vw,3.8rem); font-weight:800; line-height:1.15; }
  .hero p.lead{ color:#cbd5e1; font-size:1.15rem; max-width:600px; }
  .hero-badge{ display:inline-block; background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.2); padding:6px 16px; border-radius:999px; font-size:.85rem; font-weight:600; margin-bottom:20px; color:#a78bfa; }

  /* STATS */
  .stats-bar{ margin-top:-60px; position:relative; z-index:5; }
  .stat-card{ background:#fff; border-radius:16px; padding:25px; text-align:center; box-shadow:0 20px 40px rgba(15,23,42,.08); border-top:4px solid var(--brand); transition:.3s; }
  .stat-card:hover{ transform:translateY(-5px); }
  .stat-card h2{ font-weight:800; color:var(--brand); margin:0; }
  .stat-card p{ color:#64748b; margin:0; font-weight:500; font-size:.9rem; }

  /* SECTION HEADINGS */
  .section-title{ font-weight:800; font-size:clamp(1.8rem,4vw,2.5rem); color:var(--dark); }
  .section-subtitle{ color:#64748b; max-width:600px; margin:0 auto; }

  /* SERVICE CARDS */
  .service-card{ background:#fff; border-radius:18px; padding:30px; text-align:center; transition:.3s; height:100%; border:1px solid #e2e8f0; }
  .service-card:hover{ transform:translateY(-8px); box-shadow:0 25px 50px rgba(15,23,42,.12); border-color:transparent; }
  .service-icon{ width:70px;height:70px; margin:0 auto 20px; display:flex;align-items:center;justify-content:center; border-radius:16px; background:linear-gradient(135deg,var(--brand),var(--brand-2)); color:#fff;font-size:28px; }
  .service-card h5{ font-weight:700; margin-bottom:10px; }
  .service-card p{ color:#64748b; font-size:.95rem; margin:0; }

  /* PACKAGE CARDS */
  .package-card{ background:#fff; border-radius:18px; padding:30px 25px; text-align:center; transition:.3s; height:100%; border:1px solid #e2e8f0; position:relative; overflow:hidden; }
  .package-card:hover{ transform:translateY(-8px); box-shadow:0 25px 50px rgba(102,16,242,.15); border-color:var(--brand); }
  .package-card .cat-badge{ position:absolute; top:15px; right:-35px; background:var(--brand); color:#fff; transform:rotate(45deg); padding:6px 40px; font-size:.75rem; font-weight:700; letter-spacing:1px; }
  .package-price{ font-size:2.2rem; font-weight:800; color:var(--brand); line-height:1; }
  .package-price small{ font-size:.9rem; color:#64748b; font-weight:500; }
  .package-name{ font-weight:700; font-size:1.15rem; color:var(--dark); }
  .package-meta{ color:#64748b; font-size:.9rem; margin:8px 0 20px; }

  /* CONTACT */
  .contact-wrap{ background:linear-gradient(135deg,#1e1b4b,#4c1d95); border-radius:24px; padding:50px; color:#fff; }
  .contact-wrap .form-control{ padding:12px 15px; border-radius:10px; border:none; }
  .contact-info i{ color:#a78bfa; font-size:1.2rem; width:30px; }
  .contact-info p{ color:#cbd5e1; margin-bottom:15px; }

  /* FOOTER */
  footer{ background:#0f172a; color:#94a3b8; padding:60px 0 20px; margin-top:80px; }
  footer h6{ color:#fff; font-weight:700; margin-bottom:18px; }
  footer a{ color:#94a3b8; text-decoration:none; display:block; padding:5px 0; transition:.2s; }
  footer a:hover{ color:#a78bfa; padding-left:5px; }
  .footer-social a{ display:inline-flex; width:38px;height:38px; border-radius:50%; background:rgba(255,255,255,.08); align-items:center;justify-content:center; margin-right:8px; padding:0; }
  .footer-social a:hover{ background:var(--brand); color:#fff; padding-left:0; }
  .footer-bottom{ border-top:1px solid rgba(255,255,255,.08); padding-top:20px; margin-top:40px; }

  .cta-banner{ background:linear-gradient(135deg,var(--brand),var(--brand-2)); border-radius:24px; padding:60px 40px; color:#fff; text-align:center; }

  @media(max-width:768px){
    .hero{ padding:60px 0 80px; text-align:center; }
    .contact-wrap{ padding:30px 20px; }
    .cta-banner{ padding:40px 20px; }
    .stats-bar{ margin-top:20px; }
  }
</style>
</head>
<body>

<!-- ============ NAVBAR ============ -->
<nav class="navbar navbar-expand-lg fixed-top">
  <div class="container">
    <a class="navbar-brand" href="index.php"><i class="fas fa-wifi"></i> FortunNet</a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link active" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="#packages">Packages</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>

        <?php if (isset($_SESSION['user_id'])): ?>
          <li class="nav-item ms-lg-3">
            <a class="btn btn-brand px-3" href="customer/packages.php">
              <i class="fas fa-box"></i> My Portal
            </a>
          </li>
          <li class="nav-item ms-lg-2">
            <a class="btn btn-outline-light px-3" href="customer/logout.php">
              <i class="fas fa-sign-out-alt"></i> Logout
            </a>
          </li>
        <?php else: ?>
          <li class="nav-item ms-lg-3">
            <a class="btn btn-outline-light px-3" href="customer/login.php">
              <i class="fas fa-sign-in-alt"></i> Login
            </a>
          </li>
          <li class="nav-item ms-lg-2">
            <a class="btn btn-brand px-3" href="customer/register.php">
              <i class="fas fa-user-plus"></i> Register
            </a>
          </li>

          <!-- ⭐ ADMIN ICON (after Register) -->
          <li class="nav-item ms-lg-2">
            <a href="admin/login.php"
               class="btn-admin"
               title="Admin Login"
               aria-label="Admin Login">
              <i class="fas fa-user-shield"></i>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- ============ HERO ============ -->
<section class="hero" id="home">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <span class="hero-badge"><i class="fas fa-bolt"></i> Kenya's Fastest Prepaid WiFi</span>
        <h1>Connect Instantly.<br>Pay Only For What You Use.</h1>
        <p class="lead mt-3">FortunNet delivers lightning-fast, reliable WiFi with flexible prepaid packages. From 1 hour to 1 month — top up via M-Pesa and get online in seconds.</p>
        <div class="mt-4 d-flex flex-wrap gap-3">
          <a href="customer/register.php" class="btn btn-brand btn-lg px-4"><i class="fas fa-rocket"></i> Get Started</a>
          <a href="#packages" class="btn btn-outline-light btn-lg px-4"><i class="fas fa-box-open"></i> View Packages</a>
        </div>
        <div class="mt-4 d-flex flex-wrap gap-4">
          <div><i class="fas fa-check-circle text-success"></i> No Contracts</div>
          <div><i class="fas fa-check-circle text-success"></i> Instant Activation</div>
          <div><i class="fas fa-check-circle text-success"></i> 24/7 Support</div>
        </div>
      </div>
      <div class="col-lg-5 text-center">
        <i class="fas fa-wifi" style="font-size:14rem; color:rgba(167,139,250,.25);"></i>
      </div>
    </div>
  </div>
</section>

<!-- ============ STATS BAR ============ -->
<div class="container stats-bar">
  <div class="row g-3">
    <div class="col-md-3 col-6"><div class="stat-card"><h2><?= number_format($totalUsers) ?>+</h2><p>Happy Customers</p></div></div>
    <div class="col-md-3 col-6"><div class="stat-card"><h2><?= number_format($totalSubs) ?>+</h2><p>Subscriptions Paid</p></div></div>
    <div class="col-md-3 col-6"><div class="stat-card"><h2><?= number_format($totalHotspots) ?></h2><p>Active Hotspots</p></div></div>
    <div class="col-md-3 col-6"><div class="stat-card"><h2>99.9%</h2><p>Uptime Guarantee</p></div></div>
  </div>
</div>

<!-- ============ SERVICES ============ -->
<section class="py-5 mt-5" id="services">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="section-title">Our Services</h2>
      <p class="section-subtitle">Everything you need for a smooth, secure, always-on connection.</p>
    </div>
    <div class="row g-4">
      <?php
      $services = [
        ['fa-bolt',       'Lightning Fast',    'Up to 50 Mbps speeds perfect for streaming, gaming and work.'],
        ['fa-clock',      'Flexible Packages', 'From 1 hour to 1 year — choose exactly what you need.'],
        ['fa-mobile-alt', 'M-Pesa Payments',   'Pay instantly with M-Pesa. No cards, no hidden fees.'],
        ['fa-shield-alt', 'Secure Network',    'Enterprise-grade encryption keeps your data safe.'],
        ['fa-headset',    '24/7 Support',      'Real humans ready to help you anytime, anywhere.'],
        ['fa-wifi',       'Multiple Hotspots', 'Coverage across Nairobi and surrounding areas.'],
      ];
      foreach ($services as $s): ?>
        <div class="col-md-4 col-sm-6">
          <div class="service-card">
            <div class="service-icon"><i class="fas <?= $s[0] ?>"></i></div>
            <h5><?= $s[1] ?></h5>
            <p><?= $s[2] ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ============ PACKAGES ============ -->
<section class="py-5" id="packages" style="background:#fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="section-title">Popular Packages</h2>
      <p class="section-subtitle">Affordable bundles for every budget. Register to unlock the full catalogue.</p>
    </div>
    <div class="row g-4">
      <?php foreach ($packages as $p): ?>
        <div class="col-md-4 col-sm-6">
          <div class="package-card">
            <span class="cat-badge"><?= strtoupper(explode(' ', $p['cat'])[0]) ?></span>
            <i class="fas fa-wifi fa-2x mb-3" style="color:var(--brand)"></i>
            <div class="package-name"><?= htmlspecialchars($p['name']) ?></div>
            <div class="package-meta"><i class="far fa-clock"></i> <?= htmlspecialchars($p['duration']) ?> • <?= htmlspecialchars($p['speed']) ?></div>
            <div class="package-price mt-2">KSh <?= number_format($p['price'], 0) ?><small> only</small></div>
            <a href="customer/login.php" class="btn btn-brand w-100 mt-3">
              <i class="fas fa-shopping-cart"></i> Buy Now
            </a>
          </div>
        </div>
      <?php endforeach; if (!$packages) echo '<div class="col-12 text-center text-muted">No packages available yet.</div>'; ?>
    </div>
    <div class="text-center mt-5">
      <a href="customer/packages.php" class="btn btn-outline-brand btn-lg px-4">
        View All Packages <i class="fas fa-arrow-right"></i>
      </a>
    </div>
  </div>
</section>

<!-- ============ CTA BANNER ============ -->
<section class="py-5">
  <div class="container">
    <div class="cta-banner">
      <h2 class="fw-bold">Ready to Get Connected?</h2>
      <p class="lead mb-4">Join <?= number_format($totalUsers) ?>+ happy customers already enjoying FortunNet WiFi.</p>
      <a href="customer/register.php" class="btn btn-light btn-lg text-primary fw-bold px-5">
        <i class="fas fa-user-plus"></i> Create Free Account
      </a>
    </div>
  </div>
</section>

<!-- ============ CONTACT ============ -->
<section class="py-5" id="contact">
  <div class="container">
    <div class="contact-wrap">
      <div class="row g-4">
        <div class="col-lg-5">
          <h3 class="fw-bold mb-3">Get In Touch</h3>
          <p class="text-light mb-4">Have a question? Need help? Our support team is ready 24/7.</p>
          <div class="contact-info">
            <p><i class="fas fa-map-marker-alt"></i> Tom Mboya Street, Nairobi, Kenya</p>
            <p><i class="fas fa-phone-alt"></i> +254 700 000 000</p>
            <p><i class="fas fa-envelope"></i> support@fortunnet.co.ke</p>
            <p><i class="fas fa-clock"></i> Mon - Sun, 24/7 Support</p>
          </div>
          <div class="footer-social mt-4">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="whatsapp.php"><i class="fab fa-whatsapp"></i></a>
          </div>
        </div>
        <div class="col-lg-7">
          <?= $msg ?>
          <form method="post">
            <input type="hidden" name="contact_submit" value="1">
            <div class="row g-3">
              <div class="col-md-6">
                <input type="text" name="name" class="form-control" placeholder="Your Name *" required>
              </div>
              <div class="col-md-6">
                <input type="email" name="email" class="form-control" placeholder="Your Email *" required>
              </div>
              <div class="col-12">
                <input type="text" name="subject" class="form-control" placeholder="Subject">
              </div>
              <div class="col-12">
                <textarea name="message" class="form-control" rows="5" placeholder="Your Message *" required></textarea>
              </div>
              <div class="col-12">
                <button class="btn btn-brand btn-lg w-100"><i class="fas fa-paper-plane"></i> Send Message</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ FOOTER ============ -->
<footer>
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4 col-md-6">
        <h4 class="text-white fw-bold"><i class="fas fa-wifi text-primary"></i> FortunNet</h4>
        <p class="mt-3">Kenya's most affordable and reliable prepaid WiFi service. Get online in seconds, pay only for what you use.</p>
        <div class="footer-social mt-3">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="whatsapp.php"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
      <div class="col-lg-2 col-md-6">
        <h6>Quick Links</h6>
        <a href="#home">Home</a>
        <a href="#services">Services</a>
        <a href="#packages">Packages</a>
        <a href="#contact">Contact</a>
      </div>
      <div class="col-lg-3 col-md-6">
        <h6>Customer Portal</h6>
        <a href="customer/login.php">Login</a>
        <a href="customer/register.php">Register</a>
        <a href="customer/packages.php">Buy Package</a>
        <a href="customer/subscribed.php">My Subscriptions</a>
      </div>
      <div class="col-lg-3 col-md-6">
        <h6>Contact Info</h6>
        <p><i class="fas fa-map-marker-alt"></i> Nairobi, Kenya</p>
        <p><i class="fas fa-phone"></i> +254 700 000 000</p>
        <p><i class="fas fa-envelope"></i> support@fortunnet.co.ke</p>
        <a href="admin/login.php" class="text-muted"><i class="fas fa-user-shield"></i> Admin Login</a>
      </div>
    </div>
    <div class="footer-bottom text-center">
      <small>&copy; <?= date('Y') ?> FortunNet Prepaid WiFi. All Rights Reserved.</small>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Auto-close mobile menu on link click
  document.querySelectorAll('.navbar-nav a').forEach(link => {
    link.addEventListener('click', () => {
      const nav = document.getElementById('mainNav');
      if (nav.classList.contains('show')) {
        new bootstrap.Collapse(nav).hide();
      }
    });
  });
</script>
</body>
</html>