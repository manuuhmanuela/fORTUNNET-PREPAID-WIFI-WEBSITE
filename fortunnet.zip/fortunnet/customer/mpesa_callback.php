<?php
/*
==========================================================================
  M-PESA CALLBACK — customer/mpesa_callback.php
==========================================================================
  Safaricom calls this URL after the customer enters their PIN.
  Updates the `subscriptions` table to mark the payment as paid.

  IMPORTANT: This URL MUST be:
    - Publicly accessible (not localhost)
    - HTTPS (required for live transactions)
    - Not password-protected
==========================================================================
*/

header('Content-Type: application/json');
require_once __DIR__ . '/../config/db.php';

// Read raw input
$mpesaResponse = file_get_contents('php://input');

// Log every callback (useful for debugging)
$logFile = __DIR__ . '/mpesa_callback.log';
file_put_contents(
    $logFile,
    date('Y-m-d H:i:s') . " | " . $mpesaResponse . PHP_EOL,
    FILE_APPEND
);

$data = json_decode($mpesaResponse, true);

if (!isset($data['Body']['stkCallback'])) {
    echo json_encode(['ResultCode' => 1, 'ResultDesc' => 'Invalid payload']);
    exit;
}

$cb                = $data['Body']['stkCallback'];
$ResultCode        = $cb['ResultCode'];
$ResultDesc        = $cb['ResultDesc'];
$MerchantRequestID = $cb['MerchantRequestID'] ?? '';
$CheckoutRequestID = $cb['CheckoutRequestID'] ?? '';

// Find the matching subscription
$stmt = $pdo->prepare("SELECT * FROM subscriptions 
                       WHERE mpesa_checkout_id = ? 
                          OR (mpesa_merchant_id = ? AND mpesa_merchant_id IS NOT NULL)
                       LIMIT 1");
$stmt->execute([$CheckoutRequestID, $MerchantRequestID]);
$sub = $stmt->fetch();

if (!$sub) {
    file_put_contents($logFile,
        date('Y-m-d H:i:s') . " | NO MATCH | CheckoutID: $CheckoutRequestID | MerchantID: $MerchantRequestID" . PHP_EOL,
        FILE_APPEND
    );
    echo json_encode(['ResultCode' => 1, 'ResultDesc' => 'Subscription not found']);
    exit;
}

/* ============================================================
   SUCCESS
   ============================================================ */
if ($ResultCode == 0) {

    // Extract metadata
    $fields = [];
    foreach (($cb['CallbackMetadata']['Item'] ?? []) as $item) {
        $fields[$item['Name']] = $item['Value'] ?? null;
    }

    $receipt = $fields['MpesaReceiptNumber'] ?? ('FT' . strtoupper(substr(md5(uniqid('', true)), 0, 8)));
    $paidAmount = $fields['Amount']          ?? $sub['amount'];
    $paidPhone  = $fields['PhoneNumber']     ?? $sub['phone'];

    // Compute expiry from the package duration
    $pkg = $pdo->prepare("SELECT duration, price FROM packages WHERE id = ?");
    $pkg->execute([$sub['package_id']]);
    $p = $pkg->fetch();

    $durationStr = $p['duration'] ?? '24 hours';
    // Normalize "1 hour" / "2 hours" / "1 day" / "7 days" / "1 month" / "30 days"
    $expiresAt = date('Y-m-d H:i:s', strtotime("+{$durationStr}"));

    // Update subscription atomically
    $pdo->prepare("UPDATE subscriptions 
                   SET status      = 'paid',
                       mpesa_code  = ?,
                       phone       = ?,
                       amount      = ?,
                       paid_at     = NOW(),
                       expires_at  = ?
                   WHERE id = ? AND status != 'paid'")
        ->execute([$receipt, $paidPhone, $paidAmount, $expiresAt, $sub['id']]);

    // Audit log
    $pdo->prepare("INSERT INTO payment_logs (subscription_id, action, notes) VALUES (?,?,?)")
        ->execute([
            $sub['id'],
            'Callback Confirmed',
            "Receipt: $receipt | Amount: $paidAmount | Phone: $paidPhone | Expires: $expiresAt"
        ]);

    file_put_contents($logFile,
        date('Y-m-d H:i:s') . " | SUCCESS | Sub #{$sub['id']} | Receipt: $receipt | Amount: $paidAmount | Expires: $expiresAt" . PHP_EOL,
        FILE_APPEND
    );

/* ============================================================
   FAILED / CANCELLED
   ============================================================ */
} else {

    // Don't overwrite a paid row
    $pdo->prepare("UPDATE subscriptions 
                   SET status = 'cancelled'
                   WHERE id = ? AND status = 'pending'")
        ->execute([$sub['id']]);

    $pdo->prepare("INSERT INTO payment_logs (subscription_id, action, notes) VALUES (?,?,?)")
        ->execute([
            $sub['id'],
            'Callback Failed',
            "Code: $ResultCode | $ResultDesc | CheckoutID: $CheckoutRequestID"
        ]);

    file_put_contents($logFile,
        date('Y-m-d H:i:s') . " | FAILED | Sub #{$sub['id']} | Code: $ResultCode | $ResultDesc" . PHP_EOL,
        FILE_APPEND
    );
}

// Always acknowledge to Safaricom
echo json_encode([
    'ResultCode' => 0,
    'ResultDesc' => 'Callback received successfully'
]);