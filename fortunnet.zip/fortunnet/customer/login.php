<?php
include 'header.php';
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email=? AND password=?");
    $stmt->execute([$email,$password]);
    $u = $stmt->fetch();
    if ($u) {
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['user_name'] = $u['fullname'];
        header('Location: landing.php'); exit;
    } else { $msg = "<div class='alert alert-danger'>Invalid credentials.</div>"; }
}
?>
<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card shadow border-0">
      <div class="card-body p-4">
        <h4 class="mb-3"><i class="fas fa-sign-in-alt"></i> Customer Login</h4>
        <?= $msg ?>
        <form method="post">
          <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
          <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
          <button class="btn btn-primary w-100">Login</button>
        </form>
        <p class="mt-3 text-center">No account? <a href="register.php">Register</a></p>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>