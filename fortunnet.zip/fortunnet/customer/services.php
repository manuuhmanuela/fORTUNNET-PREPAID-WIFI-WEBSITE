<?php include 'header.php'; ?>
<h3 class="mb-4"><i class="fas fa-concierge-bell text-primary"></i> Our Services</h3>
<div class="row g-4">
  <?php
  $services = [
    ['fa-wifi','High-Speed WiFi','Reliable internet in all our hotspots.'],
    ['fa-clock','Flexible Bundles','1 hour to 1 month.'],
    ['fa-mobile-alt','M-Pesa Payment','Instant activation after payment.'],
    ['fa-shield-alt','Secure Network','Encrypted connection.'],
    ['fa-headset','24/7 Support','We are always available.'],
    ['fa-chart-line','Fast Speed','Perfect for streaming and gaming.'],
  ];
  foreach ($services as $s): ?>
  <div class="col-md-4">
    <div class="card card-hover border-0 shadow-sm h-100 p-4 text-center">
      <i class="fas <?= $s[0] ?> fa-3x text-primary mb-3"></i>
      <h5><?= $s[1] ?></h5>
      <p class="text-muted"><?= $s[2] ?></p>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php include 'footer.php'; ?>