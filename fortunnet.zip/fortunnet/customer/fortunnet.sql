-- =====================================================
-- FortunNet Prepaid WiFi Management System
-- Complete Database Schema + Seed Data
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `fortunnet` 
  DEFAULT CHARACTER SET utf8mb4 
  COLLATE utf8mb4_general_ci;

USE `fortunnet`;

-- =====================================================
-- DROP EXISTING TABLES (safe re-import)
-- =====================================================
DROP TABLE IF EXISTS `subscriptions`;
DROP TABLE IF EXISTS `packages`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `contact_messages`;
DROP TABLE IF EXISTS `hotspots`;
DROP TABLE IF EXISTS `announcements`;
DROP TABLE IF EXISTS `payment_logs`;
DROP TABLE IF EXISTS `admins`;
DROP TABLE IF EXISTS `users`;

-- =====================================================
-- TABLE: users
-- Passwords stored in PLAIN TEXT as requested
-- =====================================================
CREATE TABLE `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `fullname` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `status` ENUM('active','suspended') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: admins
-- =====================================================
CREATE TABLE `admins` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `fullname` VARCHAR(100) DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('superadmin','manager','support') DEFAULT 'manager',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: categories
-- =====================================================
CREATE TABLE `categories` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: packages
-- =====================================================
CREATE TABLE `packages` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `category_id` INT(11) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `speed` VARCHAR(50) DEFAULT '5 Mbps',
  `price` DECIMAL(10,2) NOT NULL,
  `status` ENUM('active','inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `packages_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: subscriptions
-- =====================================================
CREATE TABLE `subscriptions` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `package_id` INT(11) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `mpesa_code` VARCHAR(50) DEFAULT NULL,
  `status` ENUM('pending','paid','cancelled','expired') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `paid_at` DATETIME DEFAULT NULL,
  `expires_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `package_id` (`package_id`),
  CONSTRAINT `subs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subs_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: contact_messages
-- =====================================================
CREATE TABLE `contact_messages` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(150) DEFAULT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('new','read','replied') DEFAULT 'new',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: hotspots
-- =====================================================
CREATE TABLE `hotspots` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `status` ENUM('online','offline') DEFAULT 'online',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: announcements
-- =====================================================
CREATE TABLE `announcements` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(150) NOT NULL,
  `body` TEXT NOT NULL,
  `posted_by` VARCHAR(100) DEFAULT 'Admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE: payment_logs
-- =====================================================
CREATE TABLE `payment_logs` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `subscription_id` INT(11) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `subscription_id` (`subscription_id`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- SEED: admins (PLAIN TEXT PASSWORDS)
-- =====================================================
INSERT INTO `admins` (`username`, `fullname`, `password`, `role`) VALUES
('admin',      'System Administrator', 'admin123',    'superadmin'),
('manager',    'Peter Mwangi',         'manager123',  'manager'),
('support',    'Grace Achieng',        'support123',  'support'),
('john.doe',   'John Doe',             'john2024',    'manager'),
('mary.staff', 'Mary Wanjiku',         'mary2024',    'support');

-- =====================================================
-- SEED: categories
-- =====================================================
INSERT INTO `categories` (`name`, `description`) VALUES
('Daily Packages',      'Perfect for short sessions and quick browsing'),
('Weekly Bundles',      'Ideal for extended use across the week'),
('Monthly Bundles',     'Best value for heavy internet users'),
('Night Owl',           'Special bundles from 10 PM to 6 AM'),
('Student Packages',    'Affordable plans for students'),
('Business Plans',      'Reliable internet for offices and shops'),
('Gaming Bundles',      'Low latency for online gaming'),
('Streaming Packs',     'Unlimited data for video and music');

-- =====================================================
-- SEED: packages
-- =====================================================
INSERT INTO `packages` (`category_id`, `name`, `duration`, `speed`, `price`, `status`) VALUES
-- Daily Packages (category 1)
(1, '1 Hour',         '1 hour',     '3 Mbps',   10.00,  'active'),
(1, '2 Hours',        '2 hours',    '3 Mbps',   20.00,  'active'),
(1, '3 Hours',        '3 hours',    '5 Mbps',   25.00,  'active'),
(1, '5 Hours',        '5 hours',    '5 Mbps',   40.00,  'active'),
(1, '8 Hours',        '8 hours',    '5 Mbps',   60.00,  'active'),
(1, '1 Day',          '24 hours',   '10 Mbps',  50.00,  'active'),
(1, '2 Days',         '48 hours',   '10 Mbps',  90.00,  'active'),

-- Weekly Bundles (category 2)
(2, '1 Week',         '7 days',     '10 Mbps',  250.00, 'active'),
(2, '2 Weeks',        '14 days',    '10 Mbps',  450.00, 'active'),
(2, '3 Weeks',        '21 days',    '15 Mbps',  650.00, 'active'),

-- Monthly Bundles (category 3)
(3, '1 Month',        '30 days',    '15 Mbps',  800.00, 'active'),
(3, '2 Months',       '60 days',    '15 Mbps',  1500.00,'active'),
(3, '3 Months',       '90 days',    '20 Mbps',  2100.00,'active'),
(3, '6 Months',       '180 days',   '20 Mbps',  3800.00,'active'),

-- Night Owl (category 4)
(4, 'Night Owl 1Hr',  '1 hour',     '10 Mbps',  5.00,   'active'),
(4, 'Night Owl 4Hr',  '4 hours',    '10 Mbps',  15.00,  'active'),
(4, 'Night Owl 8Hr',  '8 hours',    '15 Mbps',  25.00,  'active'),
(4, 'Night Owl All Night','10 PM - 6 AM','20 Mbps',40.00,'active'),

-- Student Packages (category 5)
(5, 'Student Daily',  '24 hours',   '5 Mbps',   30.00,  'active'),
(5, 'Student Weekly', '7 days',     '8 Mbps',   150.00, 'active'),
(5, 'Student Monthly','30 days',    '10 Mbps',  500.00, 'active'),
(5, 'Student Exam Week','7 days',   '15 Mbps',  200.00, 'active'),

-- Business Plans (category 6)
(6, 'Business Basic', '30 days',    '20 Mbps',  2500.00,'active'),
(6, 'Business Pro',   '30 days',    '30 Mbps',  4500.00,'active'),
(6, 'Business Premium','30 days',   '50 Mbps',  8000.00,'active'),
(6, 'Business Annual','365 days',   '50 Mbps',  85000.00,'active'),

-- Gaming Bundles (category 7)
(7, 'Gamer 2 Hours',  '2 hours',    '15 Mbps',  30.00,  'active'),
(7, 'Gamer 6 Hours',  '6 hours',    '15 Mbps',  70.00,  'active'),
(7, 'Gamer Daily',    '24 hours',   '20 Mbps',  100.00, 'active'),
(7, 'Gamer Weekly',   '7 days',     '25 Mbps',  500.00, 'active'),

-- Streaming Packs (category 8)
(8, 'Stream 3 Hours', '3 hours',    '20 Mbps',  35.00,  'active'),
(8, 'Stream Daily',   '24 hours',   '25 Mbps',  80.00,  'active'),
(8, 'Stream Weekly',  '7 days',     '30 Mbps',  400.00, 'active'),
(8, 'Stream Monthly', '30 days',    '40 Mbps',  1200.00,'active');

-- =====================================================
-- SEED: users (PLAIN TEXT PASSWORDS)
-- =====================================================
INSERT INTO `users` (`fullname`, `email`, `phone`, `password`, `status`) VALUES
('Alice Wanjiru',      'alice@example.com',    '0712345678', 'alice123',    'active'),
('Brian Otieno',       'brian@example.com',    '0723456789', 'brian123',    'active'),
('Catherine Mwikali',  'catherine@example.com','0734567890', 'cathy2024',   'active'),
('David Kiprop',       'david@example.com',    '0745678901', 'david123',    'active'),
('Esther Njeri',       'esther@example.com',   '0756789012', 'esther2024',  'active'),
('Felix Mutua',        'felix@example.com',    '0767890123', 'felix123',    'active'),
('Grace Wambui',       'grace@example.com',    '0778901234', 'grace123',    'active'),
('Henry Kimani',       'henry@example.com',    '0789012345', 'henry2024',   'active'),
('Irene Achieng',      'irene@example.com',    '0790123456', 'irene123',    'active'),
('James Ochieng',      'james@example.com',    '0701234567', 'james123',    'active'),
('Kevin Maina',        'kevin@example.com',    '0711222333', 'kevin2024',   'active'),
('Lucy Nyambura',      'lucy@example.com',     '0722333444', 'lucy123',     'active'),
('Michael Otieno',     'michael@example.com',  '0733444555', 'mike2024',    'active'),
('Nancy Chebet',       'nancy@example.com',    '0744555666', 'nancy123',    'active'),
('Oscar Wekesa',       'oscar@example.com',    '0755666777', 'oscar2024',   'active'),
('Pauline Wairimu',    'pauline@example.com',  '0766777888', 'paula123',    'active'),
('Quincy Omondi',      'quincy@example.com',   '0777888999', 'quincy2024',  'active'),
('Rachel Kilonzo',     'rachel@example.com',   '0788999000', 'rachel123',   'active'),
('Samuel Ndungu',      'samuel@example.com',   '0799000111', 'sam2024',     'active'),
('Tabitha Auma',       'tabitha@example.com',  '0700111222', 'tabby123',    'active'),
('Victor Kiptoo',      'victor@example.com',   '0711333555', 'victor2024',  'active'),
('Winnie Akinyi',      'winnie@example.com',   '0722444666', 'winnie123',   'active'),
('Xavier Mbugua',      'xavier@example.com',   '0733555777', 'xavier2024',  'active'),
('Yvonne Kerubo',      'yvonne@example.com',   '0744666888', 'yvonne123',   'active'),
('Zachary Muli',       'zachary@example.com',  '0755777999', 'zach2024',    'active'),
('Faith Muthoni',      'faith@example.com',    '0766888000', 'faith123',    'suspended'),
('Joseph Kariuki',     'joseph@example.com',   '0777999111', 'joseph2024',  'active'),
('Mercy Wanjala',      'mercy@example.com',    '0788111222', 'mercy123',    'active'),
('Peter Njoroge',      'peter@example.com',    '0799222333', 'peter2024',   'active'),
('Sarah Chepkoech',    'sarah@example.com',    '0700333444', 'sarah123',    'active');

-- =====================================================
-- SEED: subscriptions (various statuses & dates)
-- =====================================================
INSERT INTO `subscriptions` (`user_id`, `package_id`, `amount`, `phone`, `mpesa_code`, `status`, `created_at`, `paid_at`, `expires_at`) VALUES
(1,  1,  10.00,  '0712345678', 'QK1A2B3C4D', 'paid',      '2024-01-15 09:00:00', '2024-01-15 09:02:00', '2024-01-15 10:02:00'),
(2,  6,  50.00,  '0723456789', 'QK2B3C4D5E', 'paid',      '2024-01-16 14:15:00', '2024-01-16 14:20:00', '2024-01-17 14:15:00'),
(3,  8,  250.00, '0734567890', 'QK3C4D5E6F', 'paid',      '2024-01-17 10:30:00', '2024-01-17 10:33:00', '2024-01-24 10:30:00'),
(4,  11, 800.00, '0745678901', 'QK4D5E6F7G', 'paid',      '2024-01-18 08:00:00', '2024-01-18 08:05:00', '2024-02-17 08:00:00'),
(5,  3,  25.00,  '0756789012', 'QK5E6F7G8H', 'paid',      '2024-01-19 12:45:00', '2024-01-19 12:50:00', '2024-01-19 15:45:00'),
(6,  1,  10.00,  '0767890123', NULL,         'pending',   '2024-01-20 16:00:00', NULL,                  NULL),
(7,  2,  20.00,  '0778901234', NULL,         'pending',   '2024-01-20 17:10:00', NULL,                  NULL),
(8,  12, 1500.00,'0789012345', 'QK6F7G8H9I', 'paid',      '2024-01-21 09:15:00', '2024-01-21 09:20:00', '2024-03-21 09:15:00'),
(9,  9,  450.00, '0790123456', 'QK7G8H9I0J', 'paid',      '2024-01-22 11:00:00', '2024-01-22 11:04:00', '2024-02-05 11:00:00'),
(10, 4,  40.00,  '0701234567', 'QK8H9I0J1K', 'paid',      '2024-01-23 13:20:00', '2024-01-23 13:25:00', '2024-01-23 18:20:00'),
(11, 5,  60.00,  '0711222333', NULL,         'cancelled', '2024-01-24 19:00:00', NULL,                  NULL),
(12, 7,  90.00,  '0722333444', 'QK9I0J1K2L', 'paid',      '2024-01-25 10:00:00', '2024-01-25 10:08:00', '2024-01-27 10:00:00'),
(13, 10, 650.00, '0733444555', 'QK0J1K2L3M', 'paid',      '2024-02-01 08:45:00', '2024-02-01 08:50:00', '2024-02-22 08:45:00'),
(14, 13, 2100.00,'0744555666', 'QK1K2L3M4N', 'paid',      '2024-02-02 09:00:00', '2024-02-02 09:05:00', '2024-05-02 09:00:00'),
(15, 15, 5.00,   '0755666777', NULL,         'pending',   '2024-02-03 22:15:00', NULL,                  NULL),
(16, 16, 15.00,  '0766777888', 'QK2L3M4N5O', 'paid',      '2024-02-03 23:00:00', '2024-02-03 23:02:00', '2024-02-04 03:00:00'),
(17, 17, 25.00,  '0777888999', 'QK3M4N5O6P', 'paid',      '2024-02-04 22:30:00', '2024-02-04 22:35:00', '2024-02-05 06:30:00'),
(18, 18, 40.00,  '0788999000', 'QK4N5O6P7Q', 'paid',      '2024-02-05 23:00:00', '2024-02-05 23:05:00', '2024-02-06 06:00:00'),
(19, 19, 30.00,  '0799000111', 'QK5O6P7Q8R', 'paid',      '2024-02-06 08:00:00', '2024-02-06 08:03:00', '2024-02-07 08:00:00'),
(20, 20, 150.00, '0700111222', 'QK6P7Q8R9S', 'paid',      '2024-02-07 10:30:00', '2024-02-07 10:35:00', '2024-02-14 10:30:00'),
(21, 21, 500.00, '0711333555', 'QK7Q8R9S0T', 'paid',      '2024-02-08 09:00:00', '2024-02-08 09:04:00', '2024-03-09 09:00:00'),
(22, 22, 200.00, '0722444666', 'QK8R9S0T1U', 'paid',      '2024-02-09 14:00:00', '2024-02-09 14:06:00', '2024-02-16 14:00:00'),
(23, 23, 2500.00,'0733555777', 'QK9S0T1U2V', 'paid',      '2024-02-10 08:15:00', '2024-02-10 08:20:00', '2024-03-11 08:15:00'),
(24, 24, 4500.00,'0744666888', 'QK0T1U2V3W', 'paid',      '2024-02-11 09:30:00', '2024-02-11 09:35:00', '2024-03-12 09:30:00'),
(25, 25, 8000.00,'0755777999', NULL,         'pending',   '2024-02-12 11:00:00', NULL,                  NULL),
(26, 3,  25.00,  '0766888000', NULL,         'cancelled', '2024-02-13 15:00:00', NULL,                  NULL),
(27, 26, 30.00,  '0777999111', 'QK1U2V3W4X', 'paid',      '2024-02-14 20:00:00', '2024-02-14 20:05:00', '2024-02-14 22:00:00'),
(28, 27, 70.00,  '0788111222', 'QK2V3W4X5Y', 'paid',      '2024-02-15 18:00:00', '2024-02-15 18:04:00', '2024-02-16 00:00:00'),
(29, 28, 100.00, '0799222333', 'QK3W4X5Y6Z', 'paid',      '2024-02-16 12:00:00', '2024-02-16 12:05:00', '2024-02-17 12:00:00'),
(30, 29, 500.00, '0700333444', 'QK4X5Y6Z7A', 'paid',      '2024-02-17 09:00:00', '2024-02-17 09:04:00', '2024-02-24 09:00:00'),
(1,  30, 35.00,  '0712345678', 'QK5Y6Z7A8B', 'paid',      '2024-02-18 13:00:00', '2024-02-18 13:05:00', '2024-02-18 16:00:00'),
(2,  31, 80.00,  '0723456789', 'QK6Z7A8B9C', 'paid',      '2024-02-19 10:00:00', '2024-02-19 10:03:00', '2024-02-20 10:00:00'),
(3,  32, 400.00, '0734567890', 'QK7A8B9C0D', 'paid',      '2024-02-20 08:00:00', '2024-02-20 08:05:00', '2024-02-27 08:00:00'),
(4,  33, 1200.00,'0745678901', 'QK8B9C0D1E', 'paid',      '2024-02-21 09:00:00', '2024-02-21 09:04:00', '2024-03-22 09:00:00'),
(5,  6,  50.00,  '0756789012', 'QK9C0D1E2F', 'paid',      '2024-02-22 10:00:00', '2024-02-22 10:05:00', '2024-02-23 10:00:00'),
(6,  8,  250.00, '0767890123', 'QK0D1E2F3G', 'paid',      '2024-02-23 11:00:00', '2024-02-23 11:04:00', '2024-03-01 11:00:00'),
(7,  11, 800.00, '0778901234', 'QK1E2F3G4H', 'paid',      '2024-02-24 12:00:00', '2024-02-24 12:05:00', '2024-03-25 12:00:00'),
(8,  2,  20.00,  '0789012345', NULL,         'pending',   '2024-02-25 14:00:00', NULL,                  NULL),
(9,  4,  40.00,  '0790123456', 'QK2F3G4H5I', 'paid',      '2024-02-26 15:00:00', '2024-02-26 15:05:00', '2024-02-26 20:00:00'),
(10, 5,  60.00,  '0701234567', 'QK3G4H5I6J', 'paid',      '2024-02-27 16:00:00', '2024-02-27 16:04:00', '2024-02-28 00:00:00'),
(11, 1,  10.00,  '0711222333', 'QK4H5I6J7K', 'paid',      '2024-02-28 17:00:00', '2024-02-28 17:05:00', '2024-02-28 18:00:00'),
(12, 6,  50.00,  '0722333444', 'QK5I6J7K8L', 'paid',      '2024-02-29 18:00:00', '2024-02-29 18:04:00', '2024-03-01 18:00:00'),
(13, 8,  250.00, '0733444555', 'QK6J7K8L9M', 'paid',      '2024-03-01 09:00:00', '2024-03-01 09:05:00', '2024-03-08 09:00:00'),
(14, 11, 800.00, '0744555666', 'QK7K8L9M0N', 'paid',      '2024-03-02 10:00:00', '2024-03-02 10:05:00', '2024-04-01 10:00:00'),
(15, 26, 30.00,  '0755666777', NULL,         'expired',   '2024-03-03 11:00:00', NULL,                  NULL),
(16, 27, 70.00,  '0766777888', 'QK8L9M0N1O', 'paid',      '2024-03-04 12:00:00', '2024-03-04 12:05:00', '2024-03-04 18:00:00'),
(17, 28, 100.00, '0777888999', 'QK9M0N1O2P', 'paid',      '2024-03-05 13:00:00', '2024-03-05 13:04:00', '2024-03-06 13:00:00'),
(18, 29, 500.00, '0788999000', 'QK0N1O2P3Q', 'paid',      '2024-03-06 14:00:00', '2024-03-06 14:05:00', '2024-03-13 14:00:00'),
(19, 23, 2500.00,'0799000111', NULL,         'pending',   '2024-03-07 15:00:00', NULL,                  NULL),
(20, 24, 4500.00,'0700111222', NULL,         'pending',   '2024-03-08 16:00:00', NULL,                  NULL);

-- =====================================================
-- SEED: contact_messages
-- =====================================================
INSERT INTO `contact_messages` (`name`, `email`, `subject`, `message`, `status`) VALUES
('Alice Wanjiru',    'alice@example.com',    'Slow connection',       'My internet is very slow today, please help.',        'new'),
('Brian Otieno',     'brian@example.com',    'Payment not received',  'I paid but my package was not activated.',            'read'),
('Catherine Mwikali','catherine@example.com','Refund request',        'I want a refund for a cancelled subscription.',        'replied'),
('David Kiprop',     'david@example.com',    'Hotspot down',          'The hotspot in my area is offline.',                  'new'),
('Esther Njeri',     'esther@example.com',   'Thank you',             'Your service is excellent, keep it up!',              'replied'),
('Felix Mutua',      'felix@example.com',    'Upgrade query',         'How can I upgrade from daily to monthly?',            'new'),
('Grace Wambui',     'grace@example.com',    'Password reset',        'I forgot my password, please help.',                  'read'),
('Henry Kimani',     'henry@example.com',    'New hotspot request',   'Please add a hotspot in Kasarani.',                   'new'),
('Irene Achieng',    'irene@example.com',    'Bundle not showing',    'My bundle is not showing after payment.',             'read'),
('James Ochieng',    'james@example.com',    'Great support',         'Thanks for the quick fix last week.',                 'replied');

-- =====================================================
-- SEED: hotspots
-- =====================================================
INSERT INTO `hotspots` (`name`, `location`, `status`) VALUES
('FortunNet CBD',        'Tom Mboya Street, Nairobi CBD',      'online'),
('FortunNet Westlands',  'Sarit Centre Area, Westlands',       'online'),
('FortunNet Kasarani',   'Kasarani Mwiki Road',                'online'),
('FortunNet Ruaka',      'Ruaka Town Centre',                  'online'),
('FortunNet Thika Road', 'Thika Road Mall',                    'offline'),
('FortunNet Embakasi',   'Pipeline, Embakasi',                 'online'),
('FortunNet Karen',      'Karen Shopping Centre',              'offline'),
('FortunNet Langata',    'Langata Road',                       'online'),
('FortunNet Rongai',     'Ongata Rongai, Main Stage',          'online'),
('FortunNet Ngong',      'Ngong Town',                         'online');

-- =====================================================
-- SEED: announcements
-- =====================================================
INSERT INTO `announcements` (`title`, `body`, `posted_by`) VALUES
('Scheduled Maintenance', 'Our network will undergo maintenance on 15th March from 2 AM to 4 AM. Expect brief downtime.', 'System Administrator'),
('New Monthly Packages!', 'We have added 6-month and annual packages at discounted prices. Check the packages page!', 'Peter Mwangi'),
('New Hotspot in Ruaka', 'FortunNet is now live in Ruaka Town Centre. Tell your friends!', 'Grace Achieng'),
('M-Pesa Payment Issues', 'If your M-Pesa payment does not reflect within 5 minutes, contact support immediately.', 'System Administrator'),
('Holiday Promo', 'Get 20% off on weekly bundles this holiday season. Use code FORTUN20 at checkout.', 'Peter Mwangi');

-- =====================================================
-- SEED: payment_logs
-- =====================================================
INSERT INTO `payment_logs` (`subscription_id`, `action`, `notes`) VALUES
(1,  'STK Push Sent',         'Customer 0712345678 initiated payment'),
(1,  'Payment Confirmed',     'M-Pesa code QK1A2B3C4D validated'),
(2,  'STK Push Sent',         'Customer 0723456789 initiated payment'),
(2,  'Payment Confirmed',     'M-Pesa code QK2B3C4D5E validated'),
(3,  'STK Push Sent',         'Customer 0734567890 initiated payment'),
(3,  'Payment Confirmed',     'M-Pesa code QK3C4D5E6F validated'),
(6,  'STK Push Sent',         'Customer 0767890123 initiated payment, awaiting callback'),
(7,  'STK Push Sent',         'Customer 0778901234 initiated payment, awaiting callback'),
(11, 'Cancelled by user',     'Customer cancelled before paying'),
(15, 'STK Push Sent',         'Customer 0755666777 initiated payment'),
(19, 'Payment Confirmed',     'M-Pesa code QK5O6P7Q8R validated'),
(20, 'Payment Confirmed',     'M-Pesa code QK6P7Q8R9S validated'),
(21, 'Payment Confirmed',     'M-Pesa code QK7Q8R9S0T validated'),
(22, 'Payment Confirmed',     'M-Pesa code QK8R9S0T1U validated'),
(23, 'Payment Confirmed',     'M-Pesa code QK9S0T1U2V validated'),
(24, 'Payment Confirmed',     'M-Pesa code QK0T1U2V3W validated'),
(25, 'STK Push Sent',         'Customer 0755777999 initiated payment, awaiting callback'),
(26, 'Cancelled by admin',    'Admin cancelled due to invalid code'),
(27, 'Payment Confirmed',     'M-Pesa code QK1U2V3W4X validated'),
(28, 'Payment Confirmed',     'M-Pesa code QK2V3W4X5Y validated');

-- =====================================================
-- Done. Import successful.
-- =====================================================