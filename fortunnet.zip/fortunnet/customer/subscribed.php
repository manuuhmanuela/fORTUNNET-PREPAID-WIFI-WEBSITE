<?php
include 'header.php';
requireCustomer();
$stmt = $pdo->prepare("SELECT s.*, p.name AS package, p.duration, c.name AS cat 
  FROM subscriptions s JOIN packages p ON p.id=s.package_id JOIN categories c ON c.id=p.category_id
  WHERE s.user_id=? ORDER BY s.id DESC");
$stmt->execute([$_SESSION['user_id']]);
$subs = $stmt->fetchAll();
?>
<h3 class="mb-4"><i class="fas fa-list text-primary"></i> My Subscriptions</h3>
<div class="table-responsive">
<table class="table table-bordered bg-white">
  <thead class="table-dark">
    <tr><th>#</th><th>Package</th><th>Category</th><th>Duration</th><th>Amount</th><th>M-Pesa Code</th><th>Status</th><th>Date</th></tr>
  </thead>
  <tbody>
  <?php foreach ($subs as $i=>$s): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><?= htmlspecialchars($s['package']) ?></td>
      <td><?= htmlspecialchars($s['cat']) ?></td>
      <td><?= htmlspecialchars($s['duration']) ?></td>
      <td>KSh <?= number_format($s['amount'],2) ?></td>
      <td><?= htmlspecialchars($s['mpesa_code'] ?: '-') ?></td>
      <td>
        <span class="badge bg-<?= $s['status']=='paid'?'success':($s['status']=='pending'?'warning':'danger') ?>">
          <?= ucfirst($s['status']) ?>
        </span>
      </td>
      <td><?= $s['created_at'] ?></td>
    </tr>
  <?php endforeach; if(!$subs) echo "<tr><td colspan='8' class='text-center'>No subscriptions yet.</td></tr>"; ?>
  </tbody>
</table>
</div>
<?php include 'footer.php'; ?>