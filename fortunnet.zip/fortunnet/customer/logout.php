<?php
// Ensure session is active before destroying it
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Clear customer session data
unset($_SESSION['user_id']);
unset($_SESSION['user_name']);

// Destroy the whole session cleanly
session_unset();
session_destroy();

// Redirect to the public home page (root index.php)
header('Location: ../index.php');
exit;