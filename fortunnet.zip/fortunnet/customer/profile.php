<?php
include 'header.php';
requireCustomer();
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$_SESSION['user_id']]);
$u = $stmt->fetch();

$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $stmt = $pdo->prepare("UPDATE users SET fullname=?, phone=?, email=? WHERE id=?");
    $stmt->execute([$_POST['fullname'], $_POST['phone'], $_POST['email'], $_SESSION['user_id']]);
    $_SESSION['user_name'] = $_POST['fullname'];
    $msg = "<div class='alert alert-success'>Profile updated.</div>";
    $stmt->execute([$_SESSION['user_id']]);
    $u = $pdo->prepare("SELECT * FROM users WHERE id=?");
    $u->execute([$_SESSION['user_id']]);
    $u = $u->fetch();
}
?>
<h3 class="mb-4"><i class="fas fa-user text-primary"></i> My Profile</h3>
<?= $msg ?>
<div class="card border-0 shadow-sm p-4 col-md-8 mx-auto">
  <form method="post">
    <div class="mb-3"><label>Full Name</label><input name="fullname" class="form-control" value="<?= htmlspecialchars($u['fullname']) ?>" required></div>
    <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($u['email']) ?>" required></div>
    <div class="mb-3"><label>Phone</label><input name="phone" class="form-control" value="<?= htmlspecialchars($u['phone']) ?>" required></div>
    <button class="btn btn-primary">Update Profile</button>
    <a href="change_password.php" class="btn btn-outline-secondary">Change Password</a>
  </form>
</div>
<?php include 'footer.php'; ?>