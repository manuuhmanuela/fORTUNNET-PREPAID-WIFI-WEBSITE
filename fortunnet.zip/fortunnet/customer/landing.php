<?php include 'header.php'; ?>
<div class="hero rounded-4">
  <div class="container text-center">
    <h1 class="display-5 fw-bold">Fast. Reliable. Affordable WiFi</h1>
    <p class="lead">Connect to FortunNet Prepaid WiFi — choose your package, pay via M-Pesa, and get online instantly.</p>
    <a href="packages.php" class="btn btn-light btn-lg mt-3">View Packages</a>
    <a href="register.php" class="btn btn-outline-light btn-lg mt-3">Get Started</a>
  </div>
</div>

<div class="row mt-5 g-4">
  <div class="col-md-4">
    <div class="card card-hover border-0 shadow-sm h-100 text-center p-4">
      <i class="fas fa-bolt fa-3x text-primary"></i>
      <h5 class="mt-3">Lightning Fast</h5>
      <p class="text-muted">High-speed internet for all your devices.</p>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card card-hover border-0 shadow-sm h-100 text-center p-4">
      <i class="fas fa-mobile-alt fa-3x text-success"></i>
      <h5 class="mt-3">Pay With M-Pesa</h5>
      <p class="text-muted">Instant activation after payment.</p>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card card-hover border-0 shadow-sm h-100 text-center p-4">
      <i class="fas fa-clock fa-3x text-warning"></i>
      <h5 class="mt-3">Flexible Packages</h5>
      <p class="text-muted">1 hour to 1 month — choose what suits you.</p>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>