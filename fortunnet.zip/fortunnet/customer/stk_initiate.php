<?php
require_once __DIR__ . '/../config/db.php';
header('Content-Type: application/json');

if (isset($_POST['submit']) || isset($_POST['phone'])) {

  date_default_timezone_set('Africa/Nairobi');

  /* ---------- SESSION + SUBSCRIPTION (optional safety) ---------- */
  $sub_id = intval($_POST['sub_id'] ?? 0);
  $sub = null;
  if (isCustomer() && $sub_id > 0) {
      $s = $pdo->prepare("SELECT s.*, p.name AS package FROM subscriptions s 
                          JOIN packages p ON p.id = s.package_id 
                          WHERE s.id = ? AND s.user_id = ?");
      $s->execute([$sub_id, $_SESSION['user_id']]);
      $sub = $s->fetch();
  }

  /* ---------- CREDENTIALS ---------- */
  $consumerKey       = 'nk16Y74eSbTaGQgc9WF8j6FigApqOMWr';
  $consumerSecret    = '40fD1vRXCq90XFaU';
  $BusinessShortCode = '174379';
  $Passkey           = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';

  /* ---------- PHONE (normalize to 2547XXXXXXXX) ---------- */
  $raw = preg_replace('/\D/', '', $_POST['phone'] ?? '');
  if (strlen($raw) === 10 && $raw[0] === '0')           $PartyA = '254' . substr($raw, 1);
  elseif (strlen($raw) === 9 && ($raw[0] === '7' || $raw[0] === '1')) $PartyA = '254' . $raw;
  elseif (strlen($raw) === 12 && substr($raw, 0, 3) === '254')         $PartyA = $raw;
  else {
      echo json_encode(['success' => false, 'errorMessage' => 'Invalid phone. Use 2547XXXXXXXX.']);
      exit;
  }
  if (!preg_match('/^254(7|1)\d{8}$/', $PartyA)) {
      echo json_encode(['success' => false, 'errorMessage' => 'Phone must start with 2547 or 2541.']);
      exit;
  }

  /* ---------- AMOUNT (from DB if we have a subscription, else POST) ---------- */
  if ($sub) {
      $Amount = intval(round($sub['amount']));
  } else {
      $Amount = intval($_POST['amount'] ?? 0);
  }
  if ($Amount < 1) {
      echo json_encode(['success' => false, 'errorMessage' => 'Invalid amount.']);
      exit;
  }

  /* ---------- WORKING CALLBACK URL (from original working code) ---------- */
  $CallBackURL      = 'https://morning-basin-87523.herokuapp.com/callback_url.php';
  $AccountReference = $sub ? 'FORTUN-' . str_pad($sub_id, 5, '0', STR_PAD_LEFT) : 'FORTUN';
  $TransactionDesc  = $sub ? substr('FortunNet ' . $sub['package'], 0, 13) : 'FortunNet';

  $Timestamp = date('YmdHis');
  $Password  = base64_encode($BusinessShortCode . $Passkey . $Timestamp);
  $headers   = ['Content-Type:application/json; charset=utf8'];

  /* ---------- ACCESS TOKEN ---------- */
  $access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  $initiate_url     = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

  $curl = curl_init($access_token_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($curl, CURLOPT_HEADER, FALSE);
  curl_setopt($curl, CURLOPT_USERPWD, $consumerKey . ':' . $consumerSecret);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($curl);
  $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  curl_close($curl);

  $result = json_decode($result);
  $access_token = $result->access_token ?? null;

  if (!$access_token) {
      echo json_encode(['success' => false, 'errorMessage' => 'Failed to get M-PESA token (HTTP ' . $status . ').']);
      exit;
  }

  /* ---------- STK PUSH ---------- */
  $stkheader = ['Content-Type:application/json', 'Authorization:Bearer ' . $access_token];

  $curl_post_data = [
    'BusinessShortCode' => $BusinessShortCode,
    'Password'          => $Password,
    'Timestamp'         => $Timestamp,
    'TransactionType'   => 'CustomerPayBillOnline',
    'Amount'            => $Amount,
    'PartyA'            => $PartyA,
    'PartyB'            => $BusinessShortCode,
    'PhoneNumber'       => $PartyA,
    'CallBackURL'       => $CallBackURL,
    'AccountReference'  => $AccountReference,
    'TransactionDesc'   => $TransactionDesc,
  ];

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $initiate_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $stkheader);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($curl_post_data));
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
  $curl_response = curl_exec($curl);
  curl_close($curl);

  /* ---------- DEBUG LOG ---------- */
  file_put_contents(__DIR__ . '/mpesa_debug.log',
      date('c') . " | PHONE=$PartyA | AMOUNT=$Amount | RESP=$curl_response" . PHP_EOL,
      FILE_APPEND);

  $response = json_decode($curl_response, true);

  /* ---------- HANDLE RESULT ---------- */
  if (is_array($response) && ($response['ResponseCode'] ?? '') === '0') {

      // Save CheckoutRequestID so callback can match later
      if ($sub) {
          $pdo->prepare("UPDATE subscriptions 
                         SET phone=?, mpesa_checkout_id=?, mpesa_merchant_id=? 
                         WHERE id=?")
              ->execute([
                  $PartyA,
                  $response['CheckoutRequestID'] ?? null,
                  $response['MerchantRequestID'] ?? null,
                  $sub_id,
              ]);

          $pdo->prepare("INSERT INTO payment_logs (subscription_id, action, notes) VALUES (?,?,?)")
              ->execute([$sub_id, 'STK Push Sent',
                  "Phone: $PartyA | Amount: $Amount | " . ($response['CheckoutRequestID'] ?? '')]);
      }

      echo json_encode([
          'success'           => true,
          'ResponseCode'      => '0',
          'message'           => $response['CustomerMessage'] ?? 'STK push sent.',
          'CheckoutRequestID' => $response['CheckoutRequestID'] ?? null,
      ]);
      exit;
  }

  /* ---------- FAILURE ---------- */
  $err = $response['errorMessage'] 
      ?? $response['ResponseDescription'] 
      ?? 'STK push failed.';

  if ($sub) {
      $pdo->prepare("INSERT INTO payment_logs (subscription_id, action, notes) VALUES (?,?,?)")
          ->execute([$sub_id, 'STK Push Failed', $err]);
  }

  echo json_encode(['success' => false, 'errorMessage' => $err]);
  exit;
}

// If the file is hit directly (no POST), show a friendly message
echo json_encode(['success' => false, 'errorMessage' => 'No data received.']);