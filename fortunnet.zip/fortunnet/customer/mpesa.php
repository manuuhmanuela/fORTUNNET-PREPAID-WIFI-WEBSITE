<?php
require_once __DIR__ . '/../config/db.php';
if (!isCustomer()) { header('Location: login.php'); exit; }

$sub_id = intval($_GET['sub_id'] ?? 0);
$phone  = trim($_GET['phone'] ?? '');

// Normalize phone → 2547XXXXXXXX
$phone = preg_replace('/\D/', '', $phone);
if (strlen($phone) === 10 && $phone[0] === '0') {
    $phone = '254' . substr($phone, 1);
} elseif (strlen($phone) === 9 && ($phone[0] === '7' || $phone[0] === '1')) {
    $phone = '254' . $phone;
}

// Load subscription
$stmt = $pdo->prepare("SELECT s.*, p.name AS package, p.duration
    FROM subscriptions s
    JOIN packages p ON p.id = s.package_id
    WHERE s.id = ? AND s.user_id = ?");
$stmt->execute([$sub_id, $_SESSION['user_id']]);
$sub = $stmt->fetch();

if (!$sub) {
    echo "<script>alert('Subscription not found.'); window.location='packages.php';</script>";
    exit;
}
if ($sub['status'] === 'paid') {
    echo "<script>alert('This subscription is already paid.'); window.location='subscribed.php';</script>";
    exit;
}

// Fallback to DB phone if none in URL
if (!$phone && !empty($sub['phone'])) {
    $phone = preg_replace('/\D/', '', $sub['phone']);
    if (strlen($phone) === 10 && $phone[0] === '0') $phone = '254' . substr($phone, 1);
}

$amount = floatval($sub['amount']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>M-PESA Payment — FortunNet</title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --green: #00a651; --green-d: #007d3c; --green-l: #e6f7ef;
      --red: #e53935; --gray: #f5f6fa; --border: #e0e4ed;
      --text: #1a1f2e; --muted: #6b7280; --white: #fff;
      --shadow: 0 4px 24px rgba(0,0,0,0.10);
    }
    body {
      font-family: 'DM Sans', sans-serif;
      background: linear-gradient(135deg, #e8f5e9 0%, #f0faf4 60%, #e3f2fd 100%);
      min-height: 100vh; display: flex; align-items: center;
      justify-content: center; padding: 16px;
    }
    .card { background: var(--white); border-radius: 20px; box-shadow: var(--shadow);
      width: 100%; max-width: 420px; overflow: hidden; }

    .card-header { background: var(--green); padding: 22px 28px 18px;
      display: flex; align-items: center; gap: 14px; }
    .mpesa-logo { background: var(--white); border-radius: 10px;
      padding: 6px 12px; display: flex; align-items: center; gap: 4px; }
    .mpesa-logo span { font-size: 18px; font-weight: 700;
      color: var(--green); letter-spacing: -0.5px; }
    .mpesa-logo .m { color: #e53935; }
    .header-text { color: var(--white); }
    .header-text h2 { font-size: 16px; font-weight: 600; }
    .header-text p { font-size: 12px; opacity: 0.85; margin-top: 2px; }

    .merchant-bar { background: var(--green-l); border-bottom: 1px solid var(--border);
      padding: 12px 28px; display: flex; align-items: center; gap: 10px; }
    .merchant-icon { width: 36px; height: 36px; border-radius: 50%;
      background: var(--green); color: var(--white);
      display: flex; align-items: center; justify-content: center;
      font-size: 16px; font-weight: 700; flex-shrink: 0; }
    .merchant-name { font-size: 14px; font-weight: 600; color: var(--text); }
    .merchant-till { font-size: 12px; color: var(--muted); margin-top: 1px; }

    .card-body { padding: 24px 28px 28px; }
    .field { margin-bottom: 18px; }
    .field label { display: block; font-size: 12px; font-weight: 600;
      color: var(--muted); text-transform: uppercase;
      letter-spacing: 0.6px; margin-bottom: 7px; }
    .input-wrap { position: relative; }
    .input-wrap .prefix { position: absolute; left: 14px; top: 50%;
      transform: translateY(-50%); font-size: 14px; font-weight: 600;
      color: var(--muted); pointer-events: none; }
    .input-wrap input { width: 100%; border: 1.5px solid var(--border);
      border-radius: 10px; padding: 13px 14px; font-size: 16px;
      font-family: inherit; color: var(--text); background: var(--gray);
      outline: none; transition: border 0.2s; }
    .input-wrap input.has-prefix { padding-left: 36px; }
    .input-wrap input:focus { border-color: var(--green); background: #fff; }
    .input-wrap input.error { border-color: var(--red); background: #fff8f8; }
    .input-wrap input:disabled { color: var(--muted); background: #eef0f5; cursor: not-allowed; }
    .input-wrap input::placeholder { color: #b0b8c9; }

    .hint { font-size: 12px; color: var(--muted); margin-top: 6px; }
    .hint span { color: var(--green); font-weight: 600; }

    .summary-box { background: var(--gray); border-radius: 12px;
      padding: 14px 16px; margin-bottom: 18px; font-size: 13px; }
    .summary-box .row { display: flex; justify-content: space-between;
      padding: 4px 0; }
    .summary-box .row span:first-child { color: var(--muted); }
    .summary-box .row span:last-child { font-weight: 600; color: var(--text); }
    .summary-box .row.total { border-top: 1px solid var(--border);
      margin-top: 6px; padding-top: 10px; font-size: 15px; }
    .summary-box .row.total span:last-child { color: var(--green); }

    .btn-pay { width: 100%; background: var(--green); color: var(--white);
      border: none; border-radius: 12px; padding: 15px;
      font-size: 16px; font-weight: 700; font-family: inherit;
      cursor: pointer; transition: background 0.2s, transform 0.1s;
      display: flex; align-items: center; justify-content: center; gap: 10px; }
    .btn-pay:hover { background: var(--green-d); }
    .btn-pay:active { transform: scale(0.98); }
    .btn-pay:disabled { background: #9ecfb6; cursor: not-allowed; transform: none; }
    .btn-pay.sent { background: #6b7280; }
    .btn-pay.sent:hover { background: #6b7280; }
    .btn-pay .spinner { width: 20px; height: 20px;
      border: 2.5px solid rgba(255,255,255,0.4);
      border-top-color: #fff; border-radius: 50%;
      animation: spin 0.7s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    .btn-cancel { display: block; text-align: center; margin-top: 14px;
      font-size: 13px; color: var(--muted); text-decoration: none; }
    .btn-cancel:hover { color: var(--red); }

    .result { margin-top: 14px; padding: 12px 16px; border-radius: 10px;
      font-size: 13px; line-height: 1.5; display: none; }
    .result.show { display: block; }
    .result.success { background: var(--green-l); color: var(--green-d);
      border: 1px solid #b5e3c9; }
    .result.error { background: #fdecea; color: var(--red);
      border: 1px solid #f5c6c3; }
    .result strong { font-weight: 700; }

    .modal-overlay { display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,0.45); z-index: 100;
      align-items: center; justify-content: center; padding: 16px; }
    .modal-overlay.show { display: flex; animation: fadeIn 0.2s; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

    .modal { background: var(--white); border-radius: 20px;
      width: 100%; max-width: 360px;
      padding: 32px 28px 28px; text-align: center;
      box-shadow: 0 8px 40px rgba(0,0,0,0.18);
      animation: slideUp 0.25s ease; }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; }
      to { transform: none; opacity: 1; } }

    .modal-icon { width: 64px; height: 64px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto 16px; font-size: 28px; }
    .modal-icon.waiting { background: #fff8e1; color: #f9a825; animation: pulse 1.5s infinite; }
    .modal-icon.success { background: var(--green-l); color: var(--green); }
    .modal-icon.error   { background: #fdecea; color: var(--red); }
    @keyframes pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.08); } }

    .modal h3 { font-size: 18px; font-weight: 700; color: var(--text); margin-bottom: 8px; }
    .modal p  { font-size: 14px; color: var(--muted); line-height: 1.6; }
    .modal .amount-display { font-size: 28px; font-weight: 700;
      color: var(--green); margin: 12px 0 4px; }
    .modal .phone-display { font-size: 14px; color: var(--muted); margin-bottom: 16px; }

    .modal-steps { background: var(--gray); border-radius: 12px;
      padding: 14px 16px; margin: 16px 0; text-align: left; }
    .modal-steps p { font-size: 13px; color: var(--text);
      margin-bottom: 6px; font-weight: 600; }
    .step { display: flex; align-items: flex-start; gap: 10px;
      font-size: 13px; color: var(--muted); margin-top: 7px; line-height: 1.4; }
    .step-num { width: 20px; height: 20px; border-radius: 50%;
      background: var(--green); color: var(--white);
      font-size: 11px; font-weight: 700; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center; }

    .btn-close-modal { width: 100%; border: 1.5px solid var(--border);
      background: var(--gray); border-radius: 10px; padding: 12px;
      font-size: 14px; font-weight: 600; color: var(--text);
      cursor: pointer; font-family: inherit; margin-top: 4px; }
    .btn-close-modal:hover { background: #eaedf4; }
    .btn-close-modal.primary { background: var(--green); color: #fff;
      border-color: var(--green); }
    .btn-close-modal.primary:hover { background: var(--green-d); }

    .footer-note { text-align: center; font-size: 12px; color: var(--muted);
      margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--border);
      display: flex; align-items: center; justify-content: center; gap: 6px; }
    .secure-badge { display: inline-flex; align-items: center; gap: 4px;
      background: var(--green-l); color: var(--green);
      border-radius: 20px; padding: 3px 10px; font-size: 11px; font-weight: 600; }

    @media (max-width: 480px) {
      .card-body { padding: 20px; }
      .card-header { padding: 18px 20px 14px; }
      .merchant-bar { padding: 10px 20px; }
    }
  </style>
</head>
<body>

<div class="card">
  <div class="card-header">
    <div class="mpesa-logo">
      <span class="m">M</span><span>-PESA</span>
    </div>
    <div class="header-text">
      <h2>Lipa na M-PESA</h2>
      <p>Secure mobile payment</p>
    </div>
  </div>

  <div class="merchant-bar">
    <div class="merchant-icon">F</div>
    <div>
      <div class="merchant-name">FortunNet Prepaid WiFi</div>
      <div class="merchant-till">Ref: FORTUN-<?= str_pad($sub['id'], 5, '0', STR_PAD_LEFT) ?></div>
    </div>
  </div>

  <div class="card-body">
    <div class="summary-box">
      <div class="row"><span>Package</span><span><?= htmlspecialchars($sub['package']) ?></span></div>
      <div class="row"><span>Duration</span><span><?= htmlspecialchars($sub['duration']) ?></span></div>
      <div class="row total"><span>Amount</span><span>KES <?= number_format($amount, 2) ?></span></div>
    </div>

    <form id="payForm">
      <div class="field">
        <label>Amount (KES)</label>
        <div class="input-wrap">
          <span class="prefix">KES</span>
          <input type="number" id="amount" class="has-prefix"
                 value="<?= number_format($amount, 2, '.', '') ?>" disabled />
        </div>
        <p class="hint">Amount is fixed by your selected package.</p>
      </div>

      <div class="field">
        <label>M-PESA Phone Number</label>
        <div class="input-wrap">
          <span class="prefix">+</span>
          <input type="tel" name="phone" id="phone" class="has-prefix"
                 placeholder="254712345678" maxlength="12"
                 value="<?= htmlspecialchars($phone) ?>" required />
        </div>
        <p class="hint">Format: <span>2547XXXXXXXX</span> (12 digits, no spaces)</p>
      </div>

      <button type="submit" class="btn-pay" id="payBtn">
        <span id="btnText">Pay Now</span>
      </button>
    </form>

    <div id="result" class="result"></div>

    <a href="packages.php" class="btn-cancel">← Cancel and go back</a>

    <div class="footer-note">
      <span class="secure-badge">🔒 Secured</span>
      Powered by Safaricom M-PESA Daraja API
    </div>
  </div>
</div>

<!-- Waiting Modal -->
<div class="modal-overlay" id="waitingModal">
  <div class="modal">
    <div class="modal-icon waiting">📲</div>
    <h3>Check Your Phone</h3>
    <div class="amount-display" id="modalAmount">KES <?= number_format($amount, 2) ?></div>
    <div class="phone-display" id="modalPhone">+<?= htmlspecialchars($phone) ?></div>
    <div class="modal-steps">
      <p>Follow these steps:</p>
      <div class="step"><div class="step-num">1</div><span>An M-PESA prompt has been sent to your phone</span></div>
      <div class="step"><div class="step-num">2</div><span>Enter your M-PESA PIN to confirm the payment</span></div>
      <div class="step"><div class="step-num">3</div><span>You will receive an SMS confirmation shortly</span></div>
    </div>
    <p style="font-size:12px;color:#9ca3af;">Waiting for confirmation… do not close this page</p>
  </div>
</div>

<!-- Success Modal -->
<div class="modal-overlay" id="successModal">
  <div class="modal">
    <div class="modal-icon success">✓</div>
    <h3>Prompt Sent!</h3>
    <div class="amount-display" id="successAmount">KES <?= number_format($amount, 2) ?></div>
    <p id="successMsg">Enter your M-PESA PIN on your phone to complete payment. Your subscription will activate automatically.</p>
    <button class="btn-close-modal primary" onclick="window.location='subscribed.php'">View My Subscriptions</button>
  </div>
</div>

<!-- Error Modal -->
<div class="modal-overlay" id="errorModal">
  <div class="modal">
    <div class="modal-icon error">✕</div>
    <h3>Payment Failed</h3>
    <p id="errorMsg">Something went wrong. Please try again.</p>
    <button class="btn-close-modal" style="margin-top:18px" onclick="closeErrorModal()">Try Again</button>
  </div>
</div>

<script>
  const SUB_ID = <?= $sub_id ?>;
  const AMOUNT = <?= $amount ?>;

  function closeErrorModal() {
    document.getElementById('errorModal').classList.remove('show');
    resetBtn();
  }

  function resetBtn() {
    const btn = document.getElementById('payBtn');
    btn.disabled = false;
    btn.classList.remove('sent');
    btn.innerHTML = '<i class="fas fa-lock"></i> Pay Now';
  }

  function markSuccess() {
    const btn = document.getElementById('payBtn');
    btn.disabled = true;                 // ← Stay disabled — prevents double sends
    btn.classList.add('sent');
    btn.innerHTML = '<i>✓</i> Prompt Sent';
  }

  function showResult(type, html) {
    const el = document.getElementById('result');
    el.className = 'result show ' + type;
    el.innerHTML = html;
  }

  document.getElementById('payForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Normalize phone
    let raw = document.getElementById('phone').value.replace(/\D/g, '');
    let phone;
    if (raw.length === 10 && raw[0] === '0')                             phone = '254' + raw.slice(1);
    else if (raw.length === 9 && (raw[0] === '7' || raw[0] === '1'))    phone = '254' + raw;
    else if (raw.length === 12 && raw.startsWith('254'))                phone = raw;
    else {
      document.getElementById('phone').classList.add('error');
      showResult('error', 'Please enter a valid Safaricom number (2547XXXXXXXX).');
      return;
    }
    if (!/^254(7|1)\d{8}$/.test(phone)) {
      document.getElementById('phone').classList.add('error');
      showResult('error', 'Phone must start with 2547 or 2541.');
      return;
    }
    document.getElementById('phone').value = phone;
    document.getElementById('phone').classList.remove('error');

    const btn = document.getElementById('payBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Sending prompt…';
    document.getElementById('result').classList.remove('show');

    document.getElementById('modalPhone').textContent = '+' + phone;
    document.getElementById('waitingModal').classList.add('show');

    const fd = new FormData();
    fd.append('sub_id', SUB_ID);
    fd.append('phone', phone);

    fetch('stk_initiate.php', { method: 'POST', body: fd })
      .then(r => r.text())      // read as text first to log raw
      .then(txt => {
        console.log('RAW stk_initiate response:', txt);

        let data;
        try {
          data = JSON.parse(txt);
        } catch (err) {
          throw new Error('Server did not return JSON. Raw: ' + txt.slice(0, 200));
        }

        document.getElementById('waitingModal').classList.remove('show');

        const ok = data.success === true || data.ResponseCode === '0';

        if (ok) {
          markSuccess();   // ← stay disabled, show "Prompt Sent ✓"
          document.getElementById('successAmount').textContent =
            'KES ' + Number(AMOUNT).toLocaleString();
          if (data.CheckoutRequestID) {
            document.getElementById('successMsg').innerHTML =
              'Prompt sent! Ref: <strong>' + data.CheckoutRequestID + '</strong><br>' +
              'Enter your M-PESA PIN on <strong>+' + phone + '</strong> to complete payment.';
          }
          document.getElementById('successModal').classList.add('show');
          showResult('success',
            '✅ <strong>M-PESA prompt sent!</strong> Check your phone for the prompt, enter your PIN, and wait for the SMS confirmation.');
        } else {
          resetBtn();       // ← reset only on failure
          document.getElementById('errorMsg').textContent =
            data.errorMessage || data.ResponseDescription || 'Payment request failed.';
          document.getElementById('errorModal').classList.add('show');
          showResult('error', '❌ ' + (data.errorMessage || 'Payment request failed.'));
        }
      })
      .catch(err => {
        document.getElementById('waitingModal').classList.remove('show');
        resetBtn();
        document.getElementById('errorMsg').textContent = err.message;
        document.getElementById('errorModal').classList.add('show');
        showResult('error', '❌ ' + err.message);
        console.error('STK error:', err);
      });
  });
</script>

<!-- Font Awesome for icons (needed for lock/check icons in button) -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</body>
</html>