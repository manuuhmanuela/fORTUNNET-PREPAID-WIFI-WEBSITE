<?php
include 'header.php';
requireCustomer();
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $old = $_POST['old']; $new = $_POST['new']; $conf = $_POST['conf'];
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id=?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch();
    if ($row['password'] !== $old) $msg = "<div class='alert alert-danger'>Old password incorrect.</div>";
    elseif ($new !== $conf) $msg = "<div class='alert alert-danger'>New passwords don't match.</div>";
    else {
        $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$new, $_SESSION['user_id']]);
        $msg = "<div class='alert alert-success'>Password changed successfully.</div>";
    }
}
?>
<h3 class="mb-4"><i class="fas fa-key text-primary"></i> Change Password</h3>
<?= $msg ?>
<div class="card border-0 shadow-sm p-4 col-md-6 mx-auto">
  <form method="post">
    <div class="mb-3"><label>Old Password</label><input type="password" name="old" class="form-control" required></div>
    <div class="mb-3"><label>New Password</label><input type="password" name="new" class="form-control" required></div>
    <div class="mb-3"><label>Confirm New Password</label><input type="password" name="conf" class="form-control" required></div>
    <button class="btn btn-primary w-100">Update Password</button>
  </form>
</div>
<?php include 'footer.php'; ?>