<?php
include 'header.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];
    if ($password !== $confirm) {
        $msg = "<div class='alert alert-danger'>Passwords do not match.</div>";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $msg = "<div class='alert alert-danger'>Email already registered.</div>";
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (fullname,email,phone,password) VALUES (?,?,?,?)");
            $stmt->execute([$fullname,$email,$phone,$password]); // NOT hashed per request
            $msg = "<div class='alert alert-success'>Registration successful! <a href='login.php'>Login now</a></div>";
        }
    }
}
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card shadow border-0">
      <div class="card-body p-4">
        <h4 class="mb-3"><i class="fas fa-user-plus"></i> Create Account</h4>
        <?= $msg ?>
        <form method="post">
          <div class="mb-3"><label>Full Name</label><input name="fullname" class="form-control" required></div>
          <div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" required></div>
          <div class="mb-3"><label>Phone</label><input name="phone" class="form-control" required></div>
          <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
          <div class="mb-3"><label>Confirm Password</label><input type="password" name="confirm" class="form-control" required></div>
          <button class="btn btn-primary w-100">Register</button>
        </form>
        <p class="mt-3 text-center">Already have an account? <a href="login.php">Login</a></p>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>