<?php
include 'header.php';
requireCustomer();
$cats = $pdo->query("SELECT * FROM categories ORDER BY id")->fetchAll();
?>
<h3 class="mb-4"><i class="fas fa-box text-primary"></i> Choose Your Package</h3>
<?php foreach ($cats as $c): 
  $pks = $pdo->prepare("SELECT * FROM packages WHERE category_id=? AND status='active'");
  $pks->execute([$c['id']]);
  $packages = $pks->fetchAll();
  if (!$packages) continue;
?>
  <h5 class="mt-4 text-secondary"><?= htmlspecialchars($c['name']) ?> Packages</h5>
  <div class="row g-3">
    <?php foreach ($packages as $p): ?>
    <div class="col-md-4 col-sm-6">
      <div class="card card-hover border-0 shadow-sm h-100">
        <div class="card-body text-center">
          <i class="fas fa-wifi fa-2x text-primary"></i>
          <h5 class="mt-2"><?= htmlspecialchars($p['name']) ?></h5>
          <p class="text-muted mb-1"><?= htmlspecialchars($p['duration']) ?></p>
          <h4 class="text-success">KSh <?= number_format($p['price'],2) ?></h4>
          <a href="pay.php?package_id=<?= $p['id'] ?>" class="btn btn-primary w-100 mt-2">Select Package</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endforeach; ?>
<?php include 'footer.php'; ?>