<?php
include 'header.php';
requireCustomer();

$package_id = intval($_GET['package_id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, c.name AS cat FROM packages p 
                       JOIN categories c ON c.id=p.category_id WHERE p.id=?");
$stmt->execute([$package_id]);
$p = $stmt->fetch();
if (!$p) { echo "<div class='alert alert-danger'>Package not found.</div>"; include 'footer.php'; exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = preg_replace('/\D/', '', $_POST['phone'] ?? '');

    // Accept: 07XXXXXXXX, 7XXXXXXXX, 2547XXXXXXXX, 01XXXXXXXX, 2541XXXXXXXX
    if (strlen($raw) === 10 && $raw[0] === '0') {
        $phone = '254' . substr($raw, 1);
    } elseif (strlen($raw) === 9 && ($raw[0] === '7' || $raw[0] === '1')) {
        $phone = '254' . $raw;
    } elseif (strlen($raw) === 12 && substr($raw, 0, 3) === '254') {
        $phone = $raw;
    } else {
        $error = "Enter a valid Safaricom number (07XXXXXXXX or 2547XXXXXXXX).";
    }

    if (!$error && !preg_match('/^254(7|1)\d{8}$/', $phone)) {
        $error = "Phone must be a Safaricom number starting with 2547 or 2541.";
    }

    if (!$error) {
        $stmt = $pdo->prepare("INSERT INTO subscriptions 
            (user_id, package_id, amount, phone, status) 
            VALUES (?,?,?,?,'pending')");
        $stmt->execute([$_SESSION['user_id'], $package_id, $p['price'], $phone]);
        $sub_id = $pdo->lastInsertId();

        header("Location: mpesa.php?sub_id=$sub_id&phone=" . urlencode($phone));
        exit;
    }
}
?>
<h3 class="mb-4"><i class="fas fa-credit-card text-primary"></i> Payment</h3>
<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm p-4">
      <h5><?= htmlspecialchars($p['name']) ?> — <?= htmlspecialchars($p['duration']) ?></h5>
      <p class="text-muted"><?= htmlspecialchars($p['cat']) ?> category</p>
      <h3 class="text-success">KSh <?= number_format($p['price'], 2) ?></h3>
      <hr>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="post">
        <label class="form-label">M-Pesa Phone Number</label>
        <input name="phone" class="form-control mb-1" 
               placeholder="254712345678 or 0712345678" 
               value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
               required>
        <small class="text-muted d-block mb-3">We accept 07XXXXXXXX, 2547XXXXXXXX, or 01XXXXXXXX.</small>
        <button class="btn btn-success w-100">
          <i class="fas fa-mobile-alt"></i> Pay Now
        </button>
      </form>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>