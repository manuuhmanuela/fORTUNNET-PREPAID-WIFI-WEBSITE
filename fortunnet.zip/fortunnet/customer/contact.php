<?php
include 'header.php';
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $msg = "<div class='alert alert-success'>Thank you! We received your message.</div>";
}
?>
<h3 class="mb-4"><i class="fas fa-envelope text-primary"></i> Contact Us</h3>
<div class="row g-4">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm p-4">
      <h5>Get In Touch</h5>
      <p><i class="fas fa-map-marker-alt text-primary"></i> Nairobi, Kenya</p>
      <p><i class="fas fa-phone text-primary"></i> +254 700 000 000</p>
      <p><i class="fas fa-envelope text-primary"></i> support@fortunnet.co.ke</p>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card border-0 shadow-sm p-4">
      <?= $msg ?>
      <form method="post">
        <div class="mb-3"><label>Name</label><input class="form-control" required></div>
        <div class="mb-3"><label>Email</label><input type="email" class="form-control" required></div>
        <div class="mb-3"><label>Message</label><textarea class="form-control" rows="4" required></textarea></div>
        <button class="btn btn-primary">Send Message</button>
      </form>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>