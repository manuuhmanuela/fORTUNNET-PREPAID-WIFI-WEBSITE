<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/db.php';
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FortunNet WiFi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body { background: #f4f6fb; }
.navbar-brand { font-weight: 800; color: #fff !important; }
.navbar { background: linear-gradient(90deg,#0d6efd,#6610f2); }
.card-hover { transition: .3s; }
.card-hover:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,.15); }
.hero { background: linear-gradient(135deg,#0d6efd,#6610f2); color: #fff; padding: 60px 0; }
@media(max-width:768px){ .hero{ padding:30px 0; text-align:center; } }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="landing.php"><i class="fas fa-wifi"></i> FortunNet</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navmenu"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navmenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link <?= $current=='landing.php'?'active':'' ?>" href="landing.php">Home</a></li>
        <li class="nav-item"><a class="nav-link <?= $current=='services.php'?'active':'' ?>" href="services.php">Services</a></li>
        <li class="nav-item"><a class="nav-link <?= $current=='contact.php'?'active':'' ?>" href="contact.php">Contact</a></li>
        <?php if (isCustomer()): ?>
          <li class="nav-item"><a class="nav-link <?= $current=='packages.php'?'active':'' ?>" href="packages.php">Packages</a></li>
          <li class="nav-item"><a class="nav-link <?= $current=='subscribed.php'?'active':'' ?>" href="subscribed.php">My Subs</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-user"></i> <?= htmlspecialchars($_SESSION['user_name']) ?></a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
              <li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>
            </ul>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
          <li class="nav-item"><a class="nav-link btn btn-light text-primary px-3 ms-2" href="register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">