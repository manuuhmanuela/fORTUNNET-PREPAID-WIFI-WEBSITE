<?php include 'header.php'; $msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $u = trim($_POST['username']); $p = $_POST['password'];
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username=? AND password=?");
    $stmt->execute([$u,$p]);
    if ($row = $stmt->fetch()) {
        $_SESSION['admin_id']=$row['id']; $_SESSION['admin_name']=$row['username'];
        header('Location: dashboard.php'); exit;
    } else $msg = "<div class='alert alert-danger'>Invalid credentials</div>";
} ?>
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-4">
      <div class="card border-0 shadow-sm p-4">
        <h4 class="text-center mb-3"><i class="fas fa-lock text-primary"></i> Admin Login</h4>
        <?= $msg ?>
        <form method="post">
          <div class="mb-3"><label>Username</label><input name="username" class="form-control" required></div>
          <div class="mb-3"><label>Password</label><input type="password" name="password" class="form-control" required></div>
          <button class="btn btn-primary w-100">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>