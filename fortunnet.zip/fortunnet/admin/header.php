<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/db.php';
$current = basename($_SERVER['PHP_SELF']);
$isLoginPage = ($current === 'login.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FortunNet Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body { background:#eef1f7; }
.sidebar { min-height:100vh; background:#212529; }
.sidebar a { color:#adb5bd; text-decoration:none; display:block; padding:12px 20px; }
.sidebar a:hover, .sidebar a.active { background:#0d6efd; color:#fff; border-radius:5px; }
.sidebar .brand { color:#fff; font-weight:800; font-size:20px; padding:20px; display:block; text-align:center; border-bottom:1px solid #343a40; }
@media (max-width:768px){ .sidebar{ min-height:auto; } }
</style>
</head>
<body>
<?php if (!$isLoginPage): ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-2 sidebar p-0">
      <span class="brand"><i class="fas fa-wifi"></i> FortunNet Admin</span>
      <a class="<?= $current=='dashboard.php'?'active':'' ?>" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a class="<?= $current=='users.php'?'active':'' ?>" href="users.php"><i class="fas fa-users"></i> Registered Users</a>
      <a class="<?= $current=='categories.php'?'active':'' ?>" href="categories.php"><i class="fas fa-tags"></i> Categories</a>
      <a class="<?= $current=='packages.php'?'active':'' ?>" href="packages.php"><i class="fas fa-box"></i> Packages</a>
      <a class="<?= $current=='subscriptions.php'?'active':'' ?>" href="subscriptions.php"><i class="fas fa-list"></i> Subscriptions</a>
      <a class="<?= $current=='payments.php'?'active':'' ?>" href="payments.php"><i class="fas fa-money-check-alt"></i> Confirm Payments</a>
      <a class="<?= $current=='mail.php'?'active':'' ?>" href="mail.php"><i class=""></i> Email Customers</a>
      <a class="<?= $current=='reports.php'?'active':'' ?>" href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
      <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
    <div class="col-md-10 p-4">
<?php endif; ?>