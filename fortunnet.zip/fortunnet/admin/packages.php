<?php include 'header.php'; requireAdmin(); $msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!empty($_POST['id'])) {
    $pdo->prepare("UPDATE packages SET category_id=?,name=?,duration=?,price=?,status=? WHERE id=?")
        ->execute([$_POST['category_id'],$_POST['name'],$_POST['duration'],$_POST['price'],$_POST['status'],$_POST['id']]);
    $msg = "<div class='alert alert-success'>Updated.</div>";
  } else {
    $pdo->prepare("INSERT INTO packages (category_id,name,duration,price,status) VALUES (?,?,?,?,?)")
        ->execute([$_POST['category_id'],$_POST['name'],$_POST['duration'],$_POST['price'],$_POST['status']]);
    $msg = "<div class='alert alert-success'>Added.</div>";
  }
}
if (isset($_GET['delete'])) { $pdo->prepare("DELETE FROM packages WHERE id=?")->execute([intval($_GET['delete'])]); header('Location: packages.php'); exit; }
$edit = null;
if (isset($_GET['edit'])) { $e=$pdo->prepare("SELECT * FROM packages WHERE id=?"); $e->execute([intval($_GET['edit'])]); $edit=$e->fetch(); }
$cats = $pdo->query("SELECT * FROM categories")->fetchAll();
$pks = $pdo->query("SELECT p.*, c.name AS cat FROM packages p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC")->fetchAll();
?>
<h3 class="mb-4"><i class="fas fa-box text-primary"></i> Packages</h3>
<?= $msg ?>
<div class="row">
<div class="col-md-4">
 <div class="card p-3 shadow-sm border-0">
  <h6><?= $edit?'Edit':'Add' ?> Package</h6>
  <form method="post">
    <input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">
    <select name="category_id" class="form-control mb-2" required>
      <option value="">-- Category --</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?= $c['id'] ?>" <?= (($edit['category_id']??'')==$c['id'])?'selected':'' ?>><?= $c['name'] ?></option>
      <?php endforeach; ?>
    </select>
    <input name="name" class="form-control mb-2" placeholder="Package name" value="<?= htmlspecialchars($edit['name'] ?? '') ?>" required>
    <input name="duration" class="form-control mb-2" placeholder="Duration e.g. 1 hour" value="<?= htmlspecialchars($edit['duration'] ?? '') ?>" required>
    <input type="number" step="0.01" name="price" class="form-control mb-2" placeholder="Price" value="<?= $edit['price'] ?? '' ?>" required>
    <select name="status" class="form-control mb-2">
      <option value="active" <?= (($edit['status']??'')=='active')?'selected':'' ?>>Active</option>
      <option value="inactive" <?= (($edit['status']??'')=='inactive')?'selected':'' ?>>Inactive</option>
    </select>
    <button class="btn btn-primary w-100">Save</button>
  </form>
 </div>
</div>
<div class="col-md-8">
 <div class="table-responsive">
 <table class="table bg-white table-bordered">
 <thead class="table-dark"><tr><th>#</th><th>Name</th><th>Category</th><th>Duration</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead>
 <tbody>
 <?php foreach ($pks as $p): ?>
 <tr><td><?= $p['id'] ?></td><td><?= htmlspecialchars($p['name']) ?></td><td><?= htmlspecialchars($p['cat']) ?></td>
 <td><?= htmlspecialchars($p['duration']) ?></td><td>KSh <?= number_format($p['price'],2) ?></td>
 <td><span class="badge bg-<?= $p['status']=='active'?'success':'secondary' ?>"><?= $p['status'] ?></span></td>
 <td><a href="?edit=<?= $p['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
 <a href="?delete=<?= $p['id'] ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-danger">Delete</a></td></tr>
 <?php endforeach; ?>
 </tbody></table></div>
</div>
</div>
<?php include 'footer.php'; ?>