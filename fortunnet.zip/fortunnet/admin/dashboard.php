<?php include 'header.php'; requireAdmin();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalSubs = $pdo->query("SELECT COUNT(*) FROM subscriptions")->fetchColumn();
$totalPaid = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status='paid'")->fetchColumn();
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM subscriptions WHERE status='paid'")->fetchColumn();
$totalPkgs = $pdo->query("SELECT COUNT(*) FROM packages")->fetchColumn();
?>
<h3 class="mb-4"><i class="fas fa-tachometer-alt text-primary"></i> Admin Dashboard</h3>
<div class="row g-3">
  <div class="col-md-3 col-6"><div class="card bg-primary text-white p-3"><h6>Total Users</h6><h3><?= $totalUsers ?></h3></div></div>
  <div class="col-md-3 col-6"><div class="card bg-success text-white p-3"><h6>Subscriptions</h6><h3><?= $totalSubs ?></h3></div></div>
  <div class="col-md-3 col-6"><div class="card bg-warning text-dark p-3"><h6>Paid</h6><h3><?= $totalPaid ?></h3></div></div>
  <div class="col-md-3 col-6"><div class="card bg-info text-white p-3"><h6>Revenue</h6><h3>KSh <?= number_format($totalRevenue,2) ?></h3></div></div>
</div>

<h5 class="mt-5">Recent Subscriptions</h5>
<div class="table-responsive">
<table class="table table-bordered bg-white">
<tr class="table-dark"><th>#</th><th>Customer</th><th>Package</th><th>Amount</th><th>Status</th><th>Date</th></tr>
<?php $rows = $pdo->query("SELECT s.*, u.fullname, p.name AS package FROM subscriptions s JOIN users u ON u.id=s.user_id JOIN packages p ON p.id=s.package_id ORDER BY s.id DESC LIMIT 10")->fetchAll();
foreach ($rows as $i=>$r): ?>
<tr><td><?= $i+1 ?></td><td><?= htmlspecialchars($r['fullname']) ?></td>
<td><?= htmlspecialchars($r['package']) ?></td><td>KSh <?= number_format($r['amount'],2) ?></td>
<td><span class="badge bg-<?= $r['status']=='paid'?'success':'warning' ?>"><?= $r['status'] ?></span></td>
<td><?= $r['created_at'] ?></td></tr>
<?php endforeach; if(!$rows) echo "<tr><td colspan=6 class='text-center'>No subscriptions</td></tr>"; ?>
</table>
</div>
<?php include 'footer.php'; ?>