<?php
include 'header.php';
requireAdmin();

/* ---------- Bulk action: mark all paid ---------- */
if (isset($_POST['mark_all_paid'])) {
    $pdo->exec("UPDATE subscriptions
                SET status = 'paid',
                    mpesa_code = COALESCE(mpesa_code, CONCAT('FT', UPPER(SUBSTRING(MD5(RAND()), 1, 8)))),
                    paid_at = COALESCE(paid_at, NOW())
                WHERE status != 'paid'");
    header('Location: subscriptions.php?marked=all');
    exit;
}

/* ---------- Single action: mark one paid ---------- */
if (isset($_GET['mark_paid'])) {
    $id = intval($_GET['mark_paid']);
    $pdo->prepare("UPDATE subscriptions
                   SET status = 'paid',
                       mpesa_code = COALESCE(mpesa_code, ?),
                       paid_at = COALESCE(paid_at, NOW())
                   WHERE id = ?")
        ->execute(['FT' . strtoupper(substr(md5(uniqid('', true)), 0, 8)), $id]);
    header('Location: subscriptions.php?marked=one');
    exit;
}

/* ---------- Load data ---------- */
$subs = $pdo->query("SELECT s.*, u.fullname, u.phone, p.name AS package
                     FROM subscriptions s
                     JOIN users u    ON u.id = s.user_id
                     JOIN packages p ON p.id = s.package_id
                     ORDER BY s.id DESC")->fetchAll();
?>

<h3 class="mb-4"><i class="fas fa-list text-primary"></i> Subscribed Packages</h3>

<?php if (isset($_GET['marked'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle"></i>
        <?= $_GET['marked'] === 'all' ? 'All subscriptions marked as paid.' : 'Subscription marked as paid.' ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<form method="post" class="mb-3"
      onsubmit="return confirm('Mark ALL pending subscriptions as paid? This cannot be undone.');">
    <button name="mark_all_paid" class="btn btn-success">
        <i class="fas fa-check-double"></i> Mark All as Paid
    </button>
    <span class="text-muted ms-2 small">
        Sets every <code>pending</code> subscription to <code>paid</code> and generates codes where missing.
    </span>
</form>

<div class="table-responsive">
<table class="table bg-white table-bordered align-middle">
<thead class="table-dark">
<tr>
    <th>#</th>
    <th>Customer</th>
    <th>Phone</th>
    <th>Package</th>
    <th>Amount</th>
    <th>Code</th>
    <th>Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach ($subs as $s): ?>
<tr>
    <td><?= $s['id'] ?></td>
    <td><?= htmlspecialchars($s['fullname']) ?></td>
    <td><?= htmlspecialchars($s['phone']) ?></td>
    <td><?= htmlspecialchars($s['package']) ?></td>
    <td>KSh <?= number_format($s['amount'], 2) ?></td>
    <td><?= htmlspecialchars($s['mpesa_code'] ?: '-') ?></td>
    <td>
        <span class="badge bg-<?= $s['status']=='paid'?'success':($s['status']=='pending'?'warning':'danger') ?>">
            <?= $s['status'] ?>
        </span>
    </td>
    <td><?= $s['created_at'] ?></td>
    <td>
        <?php if ($s['status'] !== 'paid'): ?>
            <a href="?mark_paid=<?= $s['id'] ?>"
               class="btn btn-sm btn-success"
               onclick="return confirm('Mark this subscription as paid?');">
                <i class="fas fa-check"></i> Paid
            </a>
        <?php else: ?>
            <span class="text-muted small">✓</span>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; if (!$subs) echo "<tr><td colspan='9' class='text-center'>No subscriptions</td></tr>"; ?>
</tbody>
</table>
</div>

<?php include 'footer.php'; ?>