<?php include 'header.php'; requireAdmin();
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$stmt = $pdo->prepare("SELECT s.*, u.fullname, p.name AS package FROM subscriptions s 
 JOIN users u ON u.id=s.user_id JOIN packages p ON p.id=s.package_id
 WHERE DATE(s.created_at) BETWEEN ? AND ? ORDER BY s.id DESC");
$stmt->execute([$from,$to]);
$rows = $stmt->fetchAll();
$total = array_sum(array_column($rows,'amount'));
$paid = 0; foreach ($rows as $r) if ($r['status']=='paid') $paid += $r['amount'];
?>
<h3 class="mb-4"><i class="fas fa-chart-bar text-primary"></i> Reports</h3>
<form class="row g-2 mb-3">
  <div class="col-auto"><input type="date" name="from" class="form-control" value="<?= $from ?>"></div>
  <div class="col-auto"><input type="date" name="to" class="form-control" value="<?= $to ?>"></div>
  <div class="col-auto"><button class="btn btn-primary">Filter</button></div>
  <div class="col-auto"><button onclick="window.print()" type="button" class="btn btn-secondary">Print</button></div>
</form>
<div class="row g-3 mb-3">
  <div class="col-md-4"><div class="card bg-primary text-white p-3"><h6>Total Subscriptions</h6><h3><?= count($rows) ?></h3></div></div>
  <div class="col-md-4"><div class="card bg-info text-white p-3"><h6>Gross Amount</h6><h3>KSh <?= number_format($total,2) ?></h3></div></div>
  <div class="col-md-4"><div class="card bg-success text-white p-3"><h6>Collected (Paid)</h6><h3>KSh <?= number_format($paid,2) ?></h3></div></div>
</div>
<div class="table-responsive">
<table class="table bg-white table-bordered">
<thead class="table-dark"><tr><th>#</th><th>Customer</th><th>Package</th><th>Amount</th><th>Code</th><th>Status</th><th>Date</th></tr></thead>
<tbody>
<?php foreach ($rows as $i=>$r): ?>
<tr><td><?= $i+1 ?></td><td><?= htmlspecialchars($r['fullname']) ?></td>
<td><?= htmlspecialchars($r['package']) ?></td><td>KSh <?= number_format($r['amount'],2) ?></td>
<td><?= htmlspecialchars($r['mpesa_code'] ?: '-') ?></td>
<td><?= $r['status'] ?></td><td><?= $r['created_at'] ?></td></tr>
<?php endforeach; if(!$rows) echo "<tr><td colspan=7 class='text-center'>No data</td></tr>"; ?>
</tbody></table></div>
<?php include 'footer.php'; ?>