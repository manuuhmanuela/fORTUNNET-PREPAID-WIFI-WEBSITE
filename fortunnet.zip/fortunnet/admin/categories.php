<?php include 'header.php'; requireAdmin(); $msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!empty($_POST['id'])) {
    $pdo->prepare("UPDATE categories SET name=?,description=? WHERE id=?")->execute([$_POST['name'],$_POST['description'],$_POST['id']]);
    $msg = "<div class='alert alert-success'>Updated.</div>";
  } else {
    $pdo->prepare("INSERT INTO categories (name,description) VALUES (?,?)")->execute([$_POST['name'],$_POST['description']]);
    $msg = "<div class='alert alert-success'>Added.</div>";
  }
}
if (isset($_GET['delete'])) { $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([intval($_GET['delete'])]); header('Location: categories.php'); exit; }
$edit = null;
if (isset($_GET['edit'])) { $edit = $pdo->prepare("SELECT * FROM categories WHERE id=?"); $edit->execute([intval($_GET['edit'])]); $edit=$edit->fetch(); }
$cats = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll();
?>
<h3 class="mb-4"><i class="fas fa-tags text-primary"></i> Categories</h3>
<?= $msg ?>
<div class="row">
<div class="col-md-4">
 <div class="card p-3 shadow-sm border-0">
  <h6><?= $edit?'Edit':'Add' ?> Category</h6>
  <form method="post">
    <input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">
    <input name="name" class="form-control mb-2" placeholder="Name" value="<?= htmlspecialchars($edit['name'] ?? '') ?>" required>
    <textarea name="description" class="form-control mb-2" placeholder="Description"><?= htmlspecialchars($edit['description'] ?? '') ?></textarea>
    <button class="btn btn-primary w-100">Save</button>
  </form>
 </div>
</div>
<div class="col-md-8">
 <div class="table-responsive">
 <table class="table bg-white table-bordered">
 <thead class="table-dark"><tr><th>#</th><th>Name</th><th>Description</th><th>Actions</th></tr></thead>
 <tbody>
 <?php foreach ($cats as $c): ?>
 <tr><td><?= $c['id'] ?></td><td><?= htmlspecialchars($c['name']) ?></td><td><?= htmlspecialchars($c['description']) ?></td>
 <td><a href="?edit=<?= $c['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
 <a href="?delete=<?= $c['id'] ?>" onclick="return confirm('Delete?')" class="btn btn-sm btn-danger">Delete</a></td></tr>
 <?php endforeach; ?>
 </tbody></table></div>
</div>
</div>
<?php include 'footer.php'; ?>