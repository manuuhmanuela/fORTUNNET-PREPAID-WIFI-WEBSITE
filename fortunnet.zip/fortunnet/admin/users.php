<?php include 'header.php'; requireAdmin();
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM users WHERE id=?")->execute([intval($_GET['delete'])]);
    header('Location: users.php'); exit;
}
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
?>
<h3 class="mb-4"><i class="fas fa-users text-primary"></i> Registered Users</h3>
<div class="table-responsive">
<table class="table bg-white table-bordered">
<thead class="table-dark"><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Password</th><th>Joined</th><th>Action</th></tr></thead>
<tbody>
<?php foreach ($users as $u): ?>
<tr>
<td><?= $u['id'] ?></td><td><?= htmlspecialchars($u['fullname']) ?></td>
<td><?= htmlspecialchars($u['email']) ?></td><td><?= htmlspecialchars($u['phone']) ?></td>
<td><code><?= htmlspecialchars($u['password']) ?></code></td>
<td><?= $u['created_at'] ?></td>
<td><a href="?delete=<?= $u['id'] ?>" onclick="return confirm('Delete user?')" class="btn btn-sm btn-danger">Delete</a></td>
</tr>
<?php endforeach; if(!$users) echo "<tr><td colspan=7 class='text-center'>No users</td></tr>"; ?>
</tbody></table></div>
<?php include 'footer.php'; ?>