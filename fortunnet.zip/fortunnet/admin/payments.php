<?php include 'header.php'; requireAdmin();
if (isset($_GET['confirm'])) {
    $code = 'MAN' . strtoupper(substr(md5(time()),0,6));
    $pdo->prepare("UPDATE subscriptions SET status='paid', mpesa_code=?, paid_at=NOW() WHERE id=?")->execute([$code, intval($_GET['confirm'])]);
    header('Location: payments.php'); exit;
}
if (isset($_GET['cancel'])) { $pdo->prepare("UPDATE subscriptions SET status='cancelled' WHERE id=?")->execute([intval($_GET['cancel'])]); header('Location: payments.php'); exit; }
$rows = $pdo->query("SELECT s.*, u.fullname, p.name AS package FROM subscriptions s JOIN users u ON u.id=s.user_id JOIN packages p ON p.id=s.package_id WHERE s.status='pending' ORDER BY s.id DESC")->fetchAll();
?>
<h3 class="mb-4"><i class="fas fa-money-check-alt text-primary"></i> Confirm Payments (Pending)</h3>
<div class="table-responsive">
<table class="table bg-white table-bordered">
<thead class="table-dark"><tr><th>#</th><th>Customer</th><th>Package</th><th>Amount</th><th>Date</th><th>Action</th></tr></thead>
<tbody>
<?php foreach ($rows as $s): ?>
<tr><td><?= $s['id'] ?></td><td><?= htmlspecialchars($s['fullname']) ?></td>
<td><?= htmlspecialchars($s['package']) ?></td><td>KSh <?= number_format($s['amount'],2) ?></td>
<td><?= $s['created_at'] ?></td>
<td>
<a href="?confirm=<?= $s['id'] ?>" class="btn btn-sm btn-success">Confirm Paid</a>
<a href="?cancel=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Cancel?')">Cancel</a>
</td></tr>
<?php endforeach; if(!$rows) echo "<tr><td colspan=6 class='text-center'>No pending payments</td></tr>"; ?>
</tbody></table></div>
<?php include 'footer.php'; ?>