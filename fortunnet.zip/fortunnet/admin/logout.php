<?php
// Ensure session is active before destroying it
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Clear admin session data
unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);

// Destroy the whole session cleanly
session_unset();
session_destroy();

// Redirect to the public home page (root index.php)
header('Location: ../index.php');
exit;