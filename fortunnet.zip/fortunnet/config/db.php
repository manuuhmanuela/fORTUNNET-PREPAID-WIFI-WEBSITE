<?php
// Only start the session if one isn't already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host   = 'localhost';
$dbname = 'fortunnet';
$user   = 'root';
$pass   = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

function isCustomer() { return isset($_SESSION['user_id']); }
function isAdmin()    { return isset($_SESSION['admin_id']); }
function requireCustomer() { if (!isCustomer()) { header('Location: login.php'); exit; } }
function requireAdmin()    { if (!isAdmin())    { header('Location: login.php'); exit; } }