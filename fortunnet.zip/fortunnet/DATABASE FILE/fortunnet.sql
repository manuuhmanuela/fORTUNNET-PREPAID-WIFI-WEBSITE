-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2026 at 07:05 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fortunnet`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('superadmin','manager','support') DEFAULT 'manager',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `fullname`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'System Administrator', 'admin123', 'superadmin', '2026-11-11 19:35:08'),
(2, 'manager', 'Peter Mwangi', 'manager123', 'manager', '2026-11-11 19:35:08'),
(3, 'support', 'Grace Achieng', 'support123', 'support', '2026-11-11 19:35:08'),
(4, 'john.doe', 'John Doe', 'john2024', 'manager', '2026-11-11 19:35:08'),
(5, 'mary.staff', 'Mary Wanjiku', 'mary2024', 'support', '2026-11-11 19:35:08');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `body` text NOT NULL,
  `posted_by` varchar(100) DEFAULT 'Admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `body`, `posted_by`, `created_at`) VALUES
(1, 'Scheduled Maintenance', 'Our network will undergo maintenance on 15th March from 2 AM to 4 AM. Expect brief downtime.', 'System Administrator', '2026-11-11 19:35:11'),
(2, 'New Monthly Packages!', 'We have added 6-month and annual packages at discounted prices. Check the packages page!', 'Peter Mwangi', '2026-11-11 19:35:11'),
(3, 'New Hotspot in Ruaka', 'FortunNet is now live in Ruaka Town Centre. Tell your friends!', 'Grace Achieng', '2026-11-11 19:35:11'),
(4, 'M-Pesa Payment Issues', 'If your M-Pesa payment does not reflect within 5 minutes, contact support immediately.', 'System Administrator', '2026-11-11 19:35:11'),
(5, 'Holiday Promo', 'Get 20% off on weekly bundles this holiday season. Use code FORTUN20 at checkout.', 'Peter Mwangi', '2026-11-11 19:35:11');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Daily Packages', 'Perfect for short sessions and quick browsing', '2026-11-11 19:35:09'),
(2, 'Weekly Bundles', 'Ideal for extended use across the week', '2026-11-11 19:35:09'),
(3, 'Monthly Bundles', 'Best value for heavy internet users', '2026-11-11 19:35:09'),
(4, 'Night Owl', 'Special bundles from 10 PM to 6 AM', '2026-11-11 19:35:09'),
(5, 'Student Packages', 'Affordable plans for students', '2026-11-11 19:35:09'),
(6, 'Business Plans', 'Reliable internet for offices and shops', '2026-11-11 19:35:09'),
(7, 'Gaming Bundles', 'Low latency for online gaming', '2026-11-11 19:35:09'),
(8, 'Streaming Packs', 'Unlimited data for video and music', '2026-11-11 19:35:09');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied') DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `subject`, `message`, `status`, `created_at`) VALUES
(1, 'Alice Wanjiru', 'alice@example.com', 'Slow connection', 'My internet is very slow today, please help.', 'new', '2026-11-11 19:35:10'),
(2, 'Brian Otieno', 'brian@example.com', 'Payment not received', 'I paid but my package was not activated.', 'read', '2026-11-11 19:35:10'),
(3, 'Catherine Mwikali', 'catherine@example.com', 'Refund request', 'I want a refund for a cancelled subscription.', 'replied', '2026-11-11 19:35:10'),
(4, 'David Kiprop', 'david@example.com', 'Hotspot down', 'The hotspot in my area is offline.', 'new', '2026-11-11 19:35:10'),
(5, 'Esther Njeri', 'esther@example.com', 'Thank you', 'Your service is excellent, keep it up!', 'replied', '2026-11-11 19:35:10'),
(6, 'Felix Mutua', 'felix@example.com', 'Upgrade query', 'How can I upgrade from daily to monthly?', 'new', '2026-11-11 19:35:10'),
(7, 'Grace Wambui', 'grace@example.com', 'Password reset', 'I forgot my password, please help.', 'read', '2026-11-11 19:35:10'),
(8, 'Henry Kimani', 'henry@example.com', 'New hotspot request', 'Please add a hotspot in Kasarani.', 'new', '2026-11-11 19:35:10'),
(9, 'Irene Achieng', 'irene@example.com', 'Bundle not showing', 'My bundle is not showing after payment.', 'read', '2026-11-11 19:35:10'),
(10, 'James Ochieng', 'james@example.com', 'Great support', 'Thanks for the quick fix last week.', 'replied', '2026-11-11 19:35:10');

-- --------------------------------------------------------

--
-- Table structure for table `hotspots`
--

CREATE TABLE `hotspots` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(150) NOT NULL,
  `status` enum('online','offline') DEFAULT 'online',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotspots`
--

INSERT INTO `hotspots` (`id`, `name`, `location`, `status`, `created_at`) VALUES
(1, 'FortunNet CBD', 'Tom Mboya Street, Nairobi CBD', 'online', '2026-11-11 19:35:10'),
(2, 'FortunNet Westlands', 'Sarit Centre Area, Westlands', 'online', '2026-11-11 19:35:10'),
(3, 'FortunNet Kasarani', 'Kasarani Mwiki Road', 'online', '2026-11-11 19:35:10'),
(4, 'FortunNet Ruaka', 'Ruaka Town Centre', 'online', '2026-11-11 19:35:10'),
(5, 'FortunNet Thika Road', 'Thika Road Mall', 'offline', '2026-11-11 19:35:10'),
(6, 'FortunNet Embakasi', 'Pipeline, Embakasi', 'online', '2026-11-11 19:35:10'),
(7, 'FortunNet Karen', 'Karen Shopping Centre', 'offline', '2026-11-11 19:35:10'),
(8, 'FortunNet Langata', 'Langata Road', 'online', '2026-11-11 19:35:10'),
(9, 'FortunNet Rongai', 'Ongata Rongai, Main Stage', 'online', '2026-11-11 19:35:10'),
(10, 'FortunNet Ngong', 'Ngong Town', 'online', '2026-11-11 19:35:10');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `speed` varchar(50) DEFAULT '5 Mbps',
  `price` decimal(10,2) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `category_id`, `name`, `duration`, `speed`, `price`, `status`, `created_at`) VALUES
(1, 1, '1 Hour', '1 hour', '3 Mbps', '10.00', 'active', '2026-11-11 19:35:09'),
(2, 1, '2 Hours', '2 hours', '3 Mbps', '20.00', 'active', '2026-11-11 19:35:09'),
(3, 1, '3 Hours', '3 hours', '5 Mbps', '25.00', 'active', '2026-11-11 19:35:09'),
(4, 1, '5 Hours', '5 hours', '5 Mbps', '40.00', 'active', '2026-11-11 19:35:09'),
(5, 1, '8 Hours', '8 hours', '5 Mbps', '60.00', 'active', '2026-11-11 19:35:09'),
(6, 1, '1 Day', '24 hours', '10 Mbps', '50.00', 'active', '2026-11-11 19:35:09'),
(7, 1, '2 Days', '48 hours', '10 Mbps', '90.00', 'active', '2026-11-11 19:35:09'),
(8, 2, '1 Week', '7 days', '10 Mbps', '250.00', 'active', '2026-11-11 19:35:09'),
(9, 2, '2 Weeks', '14 days', '10 Mbps', '450.00', 'active', '2026-11-11 19:35:09'),
(10, 2, '3 Weeks', '21 days', '15 Mbps', '650.00', 'active', '2026-11-11 19:35:09'),
(11, 3, '1 Month', '30 days', '15 Mbps', '800.00', 'active', '2026-11-11 19:35:09'),
(12, 3, '2 Months', '60 days', '15 Mbps', '1500.00', 'active', '2026-11-11 19:35:09'),
(13, 3, '3 Months', '90 days', '20 Mbps', '2100.00', 'active', '2026-11-11 19:35:09'),
(14, 3, '6 Months', '180 days', '20 Mbps', '3800.00', 'active', '2026-11-11 19:35:09'),
(15, 4, 'Night Owl 1Hr', '1 hour', '10 Mbps', '5.00', 'active', '2026-11-11 19:35:09'),
(16, 4, 'Night Owl 4Hr', '4 hours', '10 Mbps', '15.00', 'active', '2026-11-11 19:35:09'),
(17, 4, 'Night Owl 8Hr', '8 hours', '15 Mbps', '25.00', 'active', '2026-11-11 19:35:09'),
(18, 4, 'Night Owl All Night', '10 PM - 6 AM', '20 Mbps', '40.00', 'active', '2026-11-11 19:35:09'),
(19, 5, 'Student Daily', '24 hours', '5 Mbps', '30.00', 'active', '2026-11-11 19:35:09'),
(20, 5, 'Student Weekly', '7 days', '8 Mbps', '150.00', 'active', '2026-11-11 19:35:09'),
(21, 5, 'Student Monthly', '30 days', '10 Mbps', '500.00', 'active', '2026-11-11 19:35:09'),
(22, 5, 'Student Exam Week', '7 days', '15 Mbps', '200.00', 'active', '2026-11-11 19:35:09'),
(23, 6, 'Business Basic', '30 days', '20 Mbps', '2500.00', 'active', '2026-11-11 19:35:09'),
(24, 6, 'Business Pro', '30 days', '30 Mbps', '4500.00', 'active', '2026-11-11 19:35:09'),
(25, 6, 'Business Premium', '30 days', '50 Mbps', '8000.00', 'active', '2026-11-11 19:35:09'),
(26, 6, 'Business Annual', '365 days', '50 Mbps', '85000.00', 'active', '2026-11-11 19:35:09'),
(27, 7, 'Gamer 2 Hours', '2 hours', '15 Mbps', '30.00', 'active', '2026-11-11 19:35:09'),
(28, 7, 'Gamer 6 Hours', '6 hours', '15 Mbps', '70.00', 'active', '2026-11-11 19:35:09'),
(29, 7, 'Gamer Daily', '24 hours', '20 Mbps', '100.00', 'active', '2026-11-11 19:35:09'),
(30, 7, 'Gamer Weekly', '7 days', '25 Mbps', '500.00', 'active', '2026-11-11 19:35:09'),
(31, 8, 'Stream 3 Hours', '3 hours', '20 Mbps', '35.00', 'active', '2026-11-11 19:35:09'),
(32, 8, 'Stream Daily', '24 hours', '25 Mbps', '80.00', 'active', '2026-11-11 19:35:09'),
(33, 8, 'Stream Weekly', '7 days', '30 Mbps', '400.00', 'active', '2026-11-11 19:35:09'),
(34, 8, 'Stream Monthly', '30 days', '40 Mbps', '1200.00', 'active', '2026-11-11 19:35:09');

-- --------------------------------------------------------

--
-- Table structure for table `payment_logs`
--

CREATE TABLE `payment_logs` (
  `id` int(11) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_logs`
--

INSERT INTO `payment_logs` (`id`, `subscription_id`, `action`, `notes`, `created_at`) VALUES
(1, 1, 'STK Push Sent', 'Customer 0712345678 initiated payment', '2026-11-11 19:35:11'),
(2, 1, 'Payment Confirmed', 'M-Pesa code QK1A2B3C4D validated', '2026-11-11 19:35:11'),
(3, 2, 'STK Push Sent', 'Customer 0723456789 initiated payment', '2026-11-11 19:35:11'),
(4, 2, 'Payment Confirmed', 'M-Pesa code QK2B3C4D5E validated', '2026-11-11 19:35:11'),
(5, 3, 'STK Push Sent', 'Customer 0734567890 initiated payment', '2026-11-11 19:35:11'),
(6, 3, 'Payment Confirmed', 'M-Pesa code QK3C4D5E6F validated', '2026-11-11 19:35:11'),
(7, 6, 'STK Push Sent', 'Customer 0767890123 initiated payment, awaiting callback', '2026-11-11 19:35:11'),
(8, 7, 'STK Push Sent', 'Customer 0778901234 initiated payment, awaiting callback', '2026-11-11 19:35:11'),
(9, 11, 'Cancelled by user', 'Customer cancelled before paying', '2026-11-11 19:35:11'),
(10, 15, 'STK Push Sent', 'Customer 0755666777 initiated payment', '2026-11-11 19:35:11'),
(11, 19, 'Payment Confirmed', 'M-Pesa code QK5O6P7Q8R validated', '2026-11-11 19:35:11'),
(12, 20, 'Payment Confirmed', 'M-Pesa code QK6P7Q8R9S validated', '2026-11-11 19:35:11'),
(13, 21, 'Payment Confirmed', 'M-Pesa code QK7Q8R9S0T validated', '2026-11-11 19:35:11'),
(14, 22, 'Payment Confirmed', 'M-Pesa code QK8R9S0T1U validated', '2026-11-11 19:35:11'),
(15, 23, 'Payment Confirmed', 'M-Pesa code QK9S0T1U2V validated', '2026-11-11 19:35:11'),
(16, 24, 'Payment Confirmed', 'M-Pesa code QK0T1U2V3W validated', '2026-11-11 19:35:11'),
(17, 25, 'STK Push Sent', 'Customer 0755777999 initiated payment, awaiting callback', '2026-11-11 19:35:11'),
(18, 26, 'Cancelled by admin', 'Admin cancelled due to invalid code', '2026-11-11 19:35:11'),
(19, 27, 'Payment Confirmed', 'M-Pesa code QK1U2V3W4X validated', '2026-11-11 19:35:11'),
(20, 28, 'Payment Confirmed', 'M-Pesa code QK2V3W4X5Y validated', '2026-11-11 19:35:11'),
(21, 52, 'Payment Confirmed', 'Simulated STK: 254724753730, code FTC2A3B250', '2026-11-11 19:43:19'),
(22, 53, 'Payment Confirmed', 'Simulated STK: 254724753730, code FTC081C3BF', '2026-11-12 10:41:09'),
(23, 56, 'Payment Confirmed', 'Simulated STK: 254724753730, code FTEC25B636', '2026-11-12 10:46:43'),
(24, 57, 'Payment Confirmed', 'Simulated STK: 254724753730, code FTCB54F7EF', '2026-11-12 10:48:17'),
(25, 58, 'STK Push Failed', 'Bad Request - Invalid CallBackURL', '2026-11-12 10:49:27'),
(26, 59, 'Payment Confirmed', 'Simulated STK: 254724753730, code FT6136D14B', '2026-11-12 10:51:19'),
(27, 60, 'Payment Confirmed', 'Simulated STK: 254724753730, code FTDBCB8C1F', '2026-11-12 10:52:30'),
(28, 61, 'Payment Confirmed', 'Simulated STK: 254724753730, code FT69CC178D', '2026-11-12 11:05:51'),
(29, 62, 'Payment Confirmed', 'Simulated STK: 254724753730, code FT80C5CDE5', '2026-11-12 16:52:19'),
(30, 69, 'STK Push Sent', 'Phone: 254724753730 | Amount: 50 | ws_CO_121120262104041724753730', '2026-11-12 18:04:04');

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mpesa_code` varchar(50) DEFAULT NULL,
  `mpesa_checkout_id` varchar(100) NOT NULL,
  `mpesa_merchant_id` varchar(100) NOT NULL,
  `status` enum('pending','paid','cancelled','expired') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `user_id`, `package_id`, `amount`, `phone`, `mpesa_code`, `mpesa_checkout_id`, `mpesa_merchant_id`, `status`, `created_at`, `paid_at`, `expires_at`) VALUES
(1, 1, 1, '10.00', '0712345678', 'QK1A2B3C4D', '', '', 'paid', '2024-01-15 09:00:00', '2024-01-15 09:02:00', '2024-01-15 10:02:00'),
(2, 2, 6, '50.00', '0723456789', 'QK2B3C4D5E', '', '', 'paid', '2024-01-16 14:15:00', '2024-01-16 14:20:00', '2024-01-17 14:15:00'),
(3, 3, 8, '250.00', '0734567890', 'QK3C4D5E6F', '', '', 'paid', '2024-01-17 10:30:00', '2024-01-17 10:33:00', '2024-01-24 10:30:00'),
(4, 4, 11, '800.00', '0745678901', 'QK4D5E6F7G', '', '', 'paid', '2024-01-18 08:00:00', '2024-01-18 08:05:00', '2024-02-17 08:00:00'),
(5, 5, 3, '25.00', '0756789012', 'QK5E6F7G8H', '', '', 'paid', '2024-01-19 12:45:00', '2024-01-19 12:50:00', '2024-01-19 15:45:00'),
(6, 6, 1, '10.00', '0767890123', NULL, '', '', 'pending', '2024-01-20 16:00:00', NULL, NULL),
(7, 7, 2, '20.00', '0778901234', NULL, '', '', 'pending', '2024-01-20 17:10:00', NULL, NULL),
(8, 8, 12, '1500.00', '0789012345', 'QK6F7G8H9I', '', '', 'paid', '2024-01-21 09:15:00', '2024-01-21 09:20:00', '2024-03-21 09:15:00'),
(9, 9, 9, '450.00', '0790123456', 'QK7G8H9I0J', '', '', 'paid', '2024-01-22 11:00:00', '2024-01-22 11:04:00', '2024-02-05 11:00:00'),
(10, 10, 4, '40.00', '0701234567', 'QK8H9I0J1K', '', '', 'paid', '2024-01-23 13:20:00', '2024-01-23 13:25:00', '2024-01-23 18:20:00'),
(11, 11, 5, '60.00', '0711222333', NULL, '', '', 'cancelled', '2024-01-24 19:00:00', NULL, NULL),
(12, 12, 7, '90.00', '0722333444', 'QK9I0J1K2L', '', '', 'paid', '2024-01-25 10:00:00', '2024-01-25 10:08:00', '2024-01-27 10:00:00'),
(13, 13, 10, '650.00', '0733444555', 'QK0J1K2L3M', '', '', 'paid', '2024-02-01 08:45:00', '2024-02-01 08:50:00', '2024-02-22 08:45:00'),
(14, 14, 13, '2100.00', '0744555666', 'QK1K2L3M4N', '', '', 'paid', '2024-02-02 09:00:00', '2024-02-02 09:05:00', '2024-05-02 09:00:00'),
(15, 15, 15, '5.00', '0755666777', NULL, '', '', 'pending', '2024-02-03 22:15:00', NULL, NULL),
(16, 16, 16, '15.00', '0766777888', 'QK2L3M4N5O', '', '', 'paid', '2024-02-03 23:00:00', '2024-02-03 23:02:00', '2024-02-04 03:00:00'),
(17, 17, 17, '25.00', '0777888999', 'QK3M4N5O6P', '', '', 'paid', '2024-02-04 22:30:00', '2024-02-04 22:35:00', '2024-02-05 06:30:00'),
(18, 18, 18, '40.00', '0788999000', 'QK4N5O6P7Q', '', '', 'paid', '2024-02-05 23:00:00', '2024-02-05 23:05:00', '2024-02-06 06:00:00'),
(19, 19, 19, '30.00', '0799000111', 'QK5O6P7Q8R', '', '', 'paid', '2024-02-06 08:00:00', '2024-02-06 08:03:00', '2024-02-07 08:00:00'),
(20, 20, 20, '150.00', '0700111222', 'QK6P7Q8R9S', '', '', 'paid', '2024-02-07 10:30:00', '2024-02-07 10:35:00', '2024-02-14 10:30:00'),
(21, 21, 21, '500.00', '0711333555', 'QK7Q8R9S0T', '', '', 'paid', '2024-02-08 09:00:00', '2024-02-08 09:04:00', '2024-03-09 09:00:00'),
(22, 22, 22, '200.00', '0722444666', 'QK8R9S0T1U', '', '', 'paid', '2024-02-09 14:00:00', '2024-02-09 14:06:00', '2024-02-16 14:00:00'),
(23, 23, 23, '2500.00', '0733555777', 'QK9S0T1U2V', '', '', 'paid', '2024-02-10 08:15:00', '2024-02-10 08:20:00', '2024-03-11 08:15:00'),
(24, 24, 24, '4500.00', '0744666888', 'QK0T1U2V3W', '', '', 'paid', '2024-02-11 09:30:00', '2024-02-11 09:35:00', '2024-03-12 09:30:00'),
(25, 25, 25, '8000.00', '0755777999', NULL, '', '', 'pending', '2024-02-12 11:00:00', NULL, NULL),
(26, 26, 3, '25.00', '0766888000', NULL, '', '', 'cancelled', '2024-02-13 15:00:00', NULL, NULL),
(27, 27, 26, '30.00', '0777999111', 'QK1U2V3W4X', '', '', 'paid', '2024-02-14 20:00:00', '2024-02-14 20:05:00', '2024-02-14 22:00:00'),
(28, 28, 27, '70.00', '0788111222', 'QK2V3W4X5Y', '', '', 'paid', '2024-02-15 18:00:00', '2024-02-15 18:04:00', '2024-02-16 00:00:00'),
(29, 29, 28, '100.00', '0799222333', 'QK3W4X5Y6Z', '', '', 'paid', '2024-02-16 12:00:00', '2024-02-16 12:05:00', '2024-02-17 12:00:00'),
(30, 30, 29, '500.00', '0700333444', 'QK4X5Y6Z7A', '', '', 'paid', '2024-02-17 09:00:00', '2024-02-17 09:04:00', '2024-02-24 09:00:00'),
(31, 1, 30, '35.00', '0712345678', 'QK5Y6Z7A8B', '', '', 'paid', '2024-02-18 13:00:00', '2024-02-18 13:05:00', '2024-02-18 16:00:00'),
(32, 2, 31, '80.00', '0723456789', 'QK6Z7A8B9C', '', '', 'paid', '2024-02-19 10:00:00', '2024-02-19 10:03:00', '2024-02-20 10:00:00'),
(33, 3, 32, '400.00', '0734567890', 'QK7A8B9C0D', '', '', 'paid', '2024-02-20 08:00:00', '2024-02-20 08:05:00', '2024-02-27 08:00:00'),
(34, 4, 33, '1200.00', '0745678901', 'QK8B9C0D1E', '', '', 'paid', '2024-02-21 09:00:00', '2024-02-21 09:04:00', '2024-03-22 09:00:00'),
(35, 5, 6, '50.00', '0756789012', 'QK9C0D1E2F', '', '', 'paid', '2024-02-22 10:00:00', '2024-02-22 10:05:00', '2024-02-23 10:00:00'),
(36, 6, 8, '250.00', '0767890123', 'QK0D1E2F3G', '', '', 'paid', '2024-02-23 11:00:00', '2024-02-23 11:04:00', '2024-03-01 11:00:00'),
(37, 7, 11, '800.00', '0778901234', 'QK1E2F3G4H', '', '', 'paid', '2024-02-24 12:00:00', '2024-02-24 12:05:00', '2024-03-25 12:00:00'),
(38, 8, 2, '20.00', '0789012345', NULL, '', '', 'pending', '2024-02-25 14:00:00', NULL, NULL),
(39, 9, 4, '40.00', '0790123456', 'QK2F3G4H5I', '', '', 'paid', '2024-02-26 15:00:00', '2024-02-26 15:05:00', '2024-02-26 20:00:00'),
(40, 10, 5, '60.00', '0701234567', 'QK3G4H5I6J', '', '', 'paid', '2024-02-27 16:00:00', '2024-02-27 16:04:00', '2024-02-28 00:00:00'),
(41, 11, 1, '10.00', '0711222333', 'QK4H5I6J7K', '', '', 'paid', '2024-02-28 17:00:00', '2024-02-28 17:05:00', '2024-02-28 18:00:00'),
(42, 12, 6, '50.00', '0722333444', 'QK5I6J7K8L', '', '', 'paid', '2024-02-29 18:00:00', '2024-02-29 18:04:00', '2024-03-01 18:00:00'),
(43, 13, 8, '250.00', '0733444555', 'QK6J7K8L9M', '', '', 'paid', '2024-03-01 09:00:00', '2024-03-01 09:05:00', '2024-03-08 09:00:00'),
(44, 14, 11, '800.00', '0744555666', 'QK7K8L9M0N', '', '', 'paid', '2024-03-02 10:00:00', '2024-03-02 10:05:00', '2024-04-01 10:00:00'),
(45, 15, 26, '30.00', '0755666777', NULL, '', '', 'expired', '2024-03-03 11:00:00', NULL, NULL),
(46, 16, 27, '70.00', '0766777888', 'QK8L9M0N1O', '', '', 'paid', '2024-03-04 12:00:00', '2024-03-04 12:05:00', '2024-03-04 18:00:00'),
(47, 17, 28, '100.00', '0777888999', 'QK9M0N1O2P', '', '', 'paid', '2024-03-05 13:00:00', '2024-03-05 13:04:00', '2024-03-06 13:00:00'),
(48, 18, 29, '500.00', '0788999000', 'QK0N1O2P3Q', '', '', 'paid', '2024-03-06 14:00:00', '2024-03-06 14:05:00', '2024-03-13 14:00:00'),
(49, 19, 23, '2500.00', '0799000111', 'MAN7BBC3A', '', '', 'paid', '2024-03-07 15:00:00', '2026-11-11 22:46:52', NULL),
(50, 20, 24, '4500.00', '0700111222', 'MANE9EB0D', '', '', 'paid', '2024-03-08 16:00:00', '2026-11-11 22:46:50', NULL),
(51, 31, 2, '20.00', NULL, 'FT5E010F69', '', '', 'paid', '2026-11-11 19:39:53', '2026-11-11 22:40:11', NULL),
(52, 31, 3, '25.00', '254724753730', 'FTC2A3B250', '', '', 'paid', '2026-11-11 19:42:37', '2026-11-11 22:43:19', '2026-11-11 23:43:19'),
(53, 31, 1, '10.00', '254724753730', 'FTC081C3BF', '', '', 'paid', '2026-11-12 10:41:04', '2026-11-12 13:41:09', '2026-11-12 12:41:09'),
(54, 31, 1, '10.00', NULL, NULL, '', '', 'pending', '2026-11-12 10:41:39', NULL, NULL),
(55, 31, 1, '10.00', NULL, NULL, '', '', 'pending', '2026-11-12 10:44:07', NULL, NULL),
(56, 31, 1, '10.00', '254724753730', 'FTEC25B636', '', '', 'paid', '2026-11-12 10:45:39', '2026-11-12 13:46:42', '2026-11-12 12:46:42'),
(57, 31, 6, '50.00', '254724753730', 'FTCB54F7EF', '', '', 'paid', '2026-11-12 10:48:14', '2026-11-12 13:48:17', '2026-11-13 11:48:17'),
(58, 31, 14, '3800.00', NULL, NULL, '', '', 'pending', '2026-11-12 10:49:19', NULL, NULL),
(59, 31, 14, '3800.00', '254724753730', 'FT6136D14B', '', '', 'paid', '2026-11-12 10:50:59', '2026-11-12 13:51:18', '2027-05-11 11:51:18'),
(60, 31, 14, '3800.00', '254724753730', 'FTDBCB8C1F', '', '', 'paid', '2026-11-12 10:52:24', '2026-11-12 13:52:29', '2027-05-11 11:52:29'),
(61, 31, 14, '3800.00', '254724753730', 'FT69CC178D', '', '', 'paid', '2026-11-12 11:05:49', '2026-11-12 14:05:51', '2027-05-11 12:05:51'),
(62, 31, 2, '20.00', '254724753730', 'FT80C5CDE5', '', '', 'paid', '2026-11-12 16:52:16', '2026-11-12 19:52:19', '2026-11-12 19:52:19'),
(63, 31, 6, '50.00', '254724753730', NULL, '', '', 'pending', '2026-11-12 16:52:54', NULL, NULL),
(64, 31, 6, '50.00', '254724753730', NULL, '', '', 'pending', '2026-11-12 16:54:13', NULL, NULL),
(65, 31, 6, '50.00', '254724753730', NULL, '', '', 'pending', '2026-11-12 16:54:47', NULL, NULL),
(66, 31, 6, '50.00', '254724753730', NULL, '', '', 'pending', '2026-11-12 16:55:44', NULL, NULL),
(67, 31, 6, '50.00', '254724753730', NULL, '', '', 'pending', '2026-11-12 17:57:18', NULL, NULL),
(68, 31, 6, '50.00', '254724753730', NULL, '', '', 'pending', '2026-11-12 18:00:18', NULL, NULL),
(69, 31, 6, '50.00', '254724753730', NULL, 'ws_CO_121120262104041724753730', '17d8-470e-8046-2009b077dabf866913', 'pending', '2026-11-12 18:03:52', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('active','suspended') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `phone`, `password`, `status`, `created_at`) VALUES
(1, 'Alice Wanjiru', 'alice@example.com', '0712345678', 'alice123', 'active', '2026-11-11 19:35:09'),
(2, 'Brian Otieno', 'brian@example.com', '0723456789', 'brian123', 'active', '2026-11-11 19:35:09'),
(3, 'Catherine Mwikali', 'catherine@example.com', '0734567890', 'cathy2024', 'active', '2026-11-11 19:35:09'),
(4, 'David Kiprop', 'david@example.com', '0745678901', 'david123', 'active', '2026-11-11 19:35:09'),
(5, 'Esther Njeri', 'esther@example.com', '0756789012', 'esther2024', 'active', '2026-11-11 19:35:09'),
(6, 'Felix Mutua', 'felix@example.com', '0767890123', 'felix123', 'active', '2026-11-11 19:35:09'),
(7, 'Grace Wambui', 'grace@example.com', '0778901234', 'grace123', 'active', '2026-11-11 19:35:09'),
(8, 'Henry Kimani', 'henry@example.com', '0789012345', 'henry2024', 'active', '2026-11-11 19:35:09'),
(9, 'Irene Achieng', 'irene@example.com', '0790123456', 'irene123', 'active', '2026-11-11 19:35:09'),
(10, 'James Ochieng', 'james@example.com', '0701234567', 'james123', 'active', '2026-11-11 19:35:09'),
(11, 'Kevin Maina', 'kevin@example.com', '0711222333', 'kevin2024', 'active', '2026-11-11 19:35:09'),
(12, 'Lucy Nyambura', 'lucy@example.com', '0722333444', 'lucy123', 'active', '2026-11-11 19:35:09'),
(13, 'Michael Otieno', 'michael@example.com', '0733444555', 'mike2024', 'active', '2026-11-11 19:35:09'),
(14, 'Nancy Chebet', 'nancy@example.com', '0744555666', 'nancy123', 'active', '2026-11-11 19:35:09'),
(15, 'Oscar Wekesa', 'oscar@example.com', '0755666777', 'oscar2024', 'active', '2026-11-11 19:35:09'),
(16, 'Pauline Wairimu', 'pauline@example.com', '0766777888', 'paula123', 'active', '2026-11-11 19:35:09'),
(17, 'Quincy Omondi', 'quincy@example.com', '0777888999', 'quincy2024', 'active', '2026-11-11 19:35:09'),
(18, 'Rachel Kilonzo', 'rachel@example.com', '0788999000', 'rachel123', 'active', '2026-11-11 19:35:09'),
(19, 'Samuel Ndungu', 'samuel@example.com', '0799000111', 'sam2024', 'active', '2026-11-11 19:35:09'),
(20, 'Tabitha Auma', 'tabitha@example.com', '0700111222', 'tabby123', 'active', '2026-11-11 19:35:09'),
(21, 'Victor Kiptoo', 'victor@example.com', '0711333555', 'victor2024', 'active', '2026-11-11 19:35:09'),
(22, 'Winnie Akinyi', 'winnie@example.com', '0722444666', 'winnie123', 'active', '2026-11-11 19:35:09'),
(23, 'Xavier Mbugua', 'xavier@example.com', '0733555777', 'xavier2024', 'active', '2026-11-11 19:35:09'),
(24, 'Yvonne Kerubo', 'yvonne@example.com', '0744666888', 'yvonne123', 'active', '2026-11-11 19:35:09'),
(25, 'Zachary Muli', 'zachary@example.com', '0755777999', 'zach2024', 'active', '2026-11-11 19:35:09'),
(26, 'Faith Muthoni', 'faith@example.com', '0766888000', 'faith123', 'suspended', '2026-11-11 19:35:09'),
(27, 'Joseph Kariuki', 'joseph@example.com', '0777999111', 'joseph2024', 'active', '2026-11-11 19:35:09'),
(28, 'Mercy Wanjala', 'mercy@example.com', '0788111222', 'mercy123', 'active', '2026-11-11 19:35:09'),
(29, 'Peter Njoroge', 'peter@example.com', '0799222333', 'peter2024', 'active', '2026-11-11 19:35:09'),
(30, 'Sarah Chepkoech', 'sarah@example.com', '0700333444', 'sarah123', 'active', '2026-11-11 19:35:09'),
(31, 'kim', 'erik@gmail.com', '0724753730', '12345678', 'active', '2026-11-11 19:39:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotspots`
--
ALTER TABLE `hotspots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `payment_logs`
--
ALTER TABLE `payment_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscription_id` (`subscription_id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `package_id` (`package_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `hotspots`
--
ALTER TABLE `hotspots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `payment_logs`
--
ALTER TABLE `payment_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `packages`
--
ALTER TABLE `packages`
  ADD CONSTRAINT `packages_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_logs`
--
ALTER TABLE `payment_logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD CONSTRAINT `subs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `subs_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
